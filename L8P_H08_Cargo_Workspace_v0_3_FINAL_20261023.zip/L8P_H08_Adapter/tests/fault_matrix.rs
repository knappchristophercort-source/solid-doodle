#![cfg(unix)]

use l8p_h08_adapter::{FailureMetadata, FileBackend, FaultPoint, PersistenceOutcome, RecoveryClass};
use std::fs;
use std::path::PathBuf;
use std::time::{SystemTime, UNIX_EPOCH};

fn root(name: &str) -> PathBuf {
    let n=SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_nanos();
    std::env::temp_dir().join(format!("l8p-h08-matrix-{}-{}",name,n))
}
fn digest(bytes: &[u8]) -> [u8;32] { l8p_core::crypto::sha3_256(bytes) }
fn meta(id:&str, data:&[u8])->FailureMetadata { FailureMetadata{event_id:id.into(),input_len:data.len() as u64,input_digest:Some(digest(data)),capture_status:"Full".into(),stage:"Wire".into(),code:"Truncated".into()} }

#[test]
fn matrix_durable_and_indeterminate_paths_are_conservative() {
    let data=b"failure";
    let r=root("matrix");
    let b=FileBackend::open(&r).unwrap();
    assert_eq!(b.persist(&meta("ok",data),data),PersistenceOutcome::Persisted);
    assert_eq!(b.reconcile("ok").unwrap(),RecoveryClass::CompleteAndDurable);
    let ri=root("ind");
    let bi=FileBackend::with_fault(&ri,FaultPoint::CommitIndeterminate).unwrap();
    assert_eq!(bi.persist(&meta("ind",data),data),PersistenceOutcome::PartialOrIndeterminate);
    assert_eq!(bi.reconcile("ind").unwrap(),RecoveryClass::UnknownCommit);
    fs::remove_dir_all(r).unwrap(); fs::remove_dir_all(ri).unwrap();
}

#[test]
fn malformed_blob_is_corrupt_evidence() {
 let r=root("badblob"); let b=FileBackend::open(&r).unwrap(); let d=b"failure"; assert_eq!(b.persist(&meta("e",d),d),PersistenceOutcome::Persisted);
 use std::io::Write; let mut f=std::fs::OpenOptions::new().append(true).open(r.join("blobs/e.blob")).unwrap(); f.write_all(b"trailing").unwrap(); assert_eq!(b.reconcile("e").unwrap(),RecoveryClass::CorruptEvidence); fs::remove_dir_all(r).unwrap();
}
#[test]
fn malformed_metadata_is_corrupt_evidence() {
 let r=root("badmeta"); let b=FileBackend::open(&r).unwrap(); let d=b"failure"; assert_eq!(b.persist(&meta("e",d),d),PersistenceOutcome::Persisted);
 use std::io::Write; let mut f=std::fs::OpenOptions::new().append(true).open(r.join("metadata/e.meta")).unwrap(); f.write_all(b"trailing").unwrap(); assert_eq!(b.reconcile("e").unwrap(),RecoveryClass::CorruptEvidence); fs::remove_dir_all(r).unwrap();
}
#[test]
fn malformed_commit_marker_is_corrupt_evidence() {
 let r=root("badcommit"); let b=FileBackend::open(&r).unwrap(); let d=b"failure"; assert_eq!(b.persist(&meta("e",d),d),PersistenceOutcome::Persisted);
 use std::io::Write; let mut f=std::fs::OpenOptions::new().append(true).open(r.join("commits/e.commit")).unwrap(); f.write_all(b"trailing").unwrap(); assert_eq!(b.reconcile("e").unwrap(),RecoveryClass::CorruptEvidence); fs::remove_dir_all(r).unwrap();
}





#[test]
fn malicious_event_id_is_rejected_without_path_access() {
    let r=root("path-traversal"); let b=FileBackend::open(&r).unwrap();
    assert_eq!(b.reconcile("../outside").unwrap(),RecoveryClass::CorruptEvidence);
    assert!(b.begin("../outside").is_err());
    fs::remove_dir_all(r).unwrap();
}

#[test]
fn oversized_declared_blob_length_is_corrupt_without_large_allocation() {
    let r=root("oversized-blob"); let b=FileBackend::open(&r).unwrap(); let d=b"failure";
    assert_eq!(b.persist(&meta("e",d),d),PersistenceOutcome::Persisted);
    let path=r.join("blobs/e.blob");
    let mut bytes=fs::read(&path).unwrap();
    bytes[5..13].copy_from_slice(&u64::MAX.to_be_bytes());
    fs::write(&path,bytes).unwrap();
    assert_eq!(b.reconcile("e").unwrap(),RecoveryClass::CorruptEvidence);
    fs::remove_dir_all(r).unwrap();
}

#[test]
fn legacy_v1_commit_marker_remains_readable() {
    let r=root("legacy-commit"); let b=FileBackend::open(&r).unwrap(); let d=b"failure";
    assert_eq!(b.persist(&meta("e",d),d),PersistenceOutcome::Persisted);
    fs::write(r.join("commits/e.commit"), [b"L8C1".to_vec(), vec![1], b"e".to_vec()].concat()).unwrap();
    assert_eq!(b.reconcile("e").unwrap(),RecoveryClass::CompleteAndDurable);
    fs::remove_dir_all(r).unwrap();
}
