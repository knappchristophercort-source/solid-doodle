#![cfg(unix)]

use l8p_h08_adapter::{FileBackend, RecoveryClass};
use std::process::Command;
use std::time::{SystemTime, UNIX_EPOCH};

fn root(label: &str) -> std::path::PathBuf {
    let n = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_nanos();
    std::env::temp_dir().join(format!("l8p-h08-crash-{}-{}", label, n))
}

#[test]
fn process_crash_boundaries_are_conservative() {
    let cases = [("blob", RecoveryClass::OrphanBlob),
                 ("metadata", RecoveryClass::UnknownCommit),
                 ("barrier", RecoveryClass::UnknownCommit),
                 ("post-commit", RecoveryClass::CompleteAndDurable)];
    for (point, expected) in cases {
        let dir = root(point);
        let status = Command::new(env!("CARGO_BIN_EXE_h08_crash_driver"))
            .arg(&dir).arg("event").arg(point).status().unwrap();
        assert!(!status.success(), "crash point must terminate abnormally");
        let backend = FileBackend::open(&dir).unwrap();
        assert_eq!(backend.reconcile("event").unwrap(), expected);
        let _ = std::fs::remove_dir_all(dir);
    }
}
