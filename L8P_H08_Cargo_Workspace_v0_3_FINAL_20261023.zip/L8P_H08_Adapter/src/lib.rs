//! L8P H-08 deployment adapter.
//!
//! This crate is deliberately separate from `l8p_core`: H1.3's evidentiary
//! semantics are frozen in the core, while durability, restart recovery and
//! backend fault semantics belong to deployment policy.

use std::fs::{self, File, OpenOptions};
use std::io::{self, Read, Write};
use std::path::{Path, PathBuf};

const VERSION: u8 = 1;
const META_MAGIC: &[u8; 4] = b"L8M1";
const BLOB_MAGIC: &[u8; 4] = b"L8B1";
const COMMIT_MAGIC_V1: &[u8; 4] = b"L8C1";
const COMMIT_MAGIC_V2: &[u8; 4] = b"L8C2";
const MAX_STRING_BYTES: usize = 4096;
const MAX_BLOB_BYTES: u64 = 1_048_576;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum PersistenceOutcome {
    InMemoryOnly,
    Persisted,
    Failed,
    PartialOrIndeterminate,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum RecoveryClass {
    CompleteAndDurable,
    Incomplete,
    MissingBlob,
    OrphanBlob,
    DigestMismatch,
    DuplicateConflict,
    UnknownCommit,
    CorruptEvidence,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum FaultPoint {
    None,
    Begin,
    BlobWrite,
    MetadataWrite,
    DurabilityBarrier,
    CommitIndeterminate,
    PostCommitIndeterminate,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct FailureMetadata {
    pub event_id: String,
    pub input_len: u64,
    pub input_digest: Option<[u8; 32]>,
    pub capture_status: String,
    pub stage: String,
    pub code: String,
}

impl FailureMetadata {
    pub fn validate(&self) -> io::Result<()> {
        validate_event_id(&self.event_id)?;
        if self.capture_status.is_empty() || self.capture_status.len() > 32 {
            return Err(io::Error::new(io::ErrorKind::InvalidInput, "invalid capture_status"));
        }
        if self.stage.is_empty() || self.stage.len() > 32 || self.code.is_empty() || self.code.len() > 128 {
            return Err(io::Error::new(io::ErrorKind::InvalidInput, "invalid failure classification"));
        }
        Ok(())
    }
}

#[derive(Debug)]
pub struct FileBackend {
    root: PathBuf,
    fault: FaultPoint,
}

impl FileBackend {
    pub fn open(root: impl AsRef<Path>) -> io::Result<Self> {
        fs::create_dir_all(root.as_ref())?;
        fs::create_dir_all(root.as_ref().join("blobs"))?;
        fs::create_dir_all(root.as_ref().join("metadata"))?;
        fs::create_dir_all(root.as_ref().join("commits"))?;
        Ok(Self { root: root.as_ref().to_path_buf(), fault: FaultPoint::None })
    }

    pub fn with_fault(root: impl AsRef<Path>, fault: FaultPoint) -> io::Result<Self> {
        let mut b = Self::open(root)?;
        b.fault = fault;
        Ok(b)
    }

    pub fn root(&self) -> &Path { &self.root }

    fn blob_path(&self, id: &str) -> PathBuf { self.root.join("blobs").join(format!("{}.blob", id)) }
    fn meta_path(&self, id: &str) -> PathBuf { self.root.join("metadata").join(format!("{}.meta", id)) }
    fn commit_path(&self, id: &str) -> PathBuf { self.root.join("commits").join(format!("{}.commit", id)) }
    fn tmp_path(path: &Path) -> PathBuf { path.with_extension("tmp") }

    fn fail(&self, point: FaultPoint) -> io::Result<()> {
        if self.fault == point {
            return Err(io::Error::new(io::ErrorKind::Other, format!("injected {:?}", point)));
        }
        Ok(())
    }

    pub fn begin(&self, event_id: &str) -> io::Result<()> {
        validate_event_id(event_id)?;
        self.fail(FaultPoint::Begin)?;
        Ok(())
    }

    pub fn write_blob(&self, event_id: &str, bytes: &[u8]) -> io::Result<()> {
        validate_event_id(event_id)?;
        self.fail(FaultPoint::BlobWrite)?;
        let final_path = self.blob_path(event_id);
        if final_path.exists() { return Err(io::Error::new(io::ErrorKind::AlreadyExists, "duplicate event id")); }
        let tmp = Self::tmp_path(&final_path);
        let mut f = OpenOptions::new().write(true).create_new(true).open(&tmp)?;
        f.write_all(BLOB_MAGIC)?;
        f.write_all(&[VERSION])?;
        f.write_all(&(bytes.len() as u64).to_be_bytes())?;
        f.write_all(bytes)?;
        f.sync_all()?;
        fs::rename(&tmp, &final_path)?;
        // Make the renamed blob entry durable before reporting this stage complete.
        sync_parent_directory(&final_path)?;
        Ok(())
    }

    pub fn write_metadata(&self, meta: &FailureMetadata) -> io::Result<()> {
        self.fail(FaultPoint::MetadataWrite)?;
        meta.validate()?;
        let final_path = self.meta_path(&meta.event_id);
        if final_path.exists() { return Err(io::Error::new(io::ErrorKind::AlreadyExists, "duplicate event id")); }
        let tmp = Self::tmp_path(&final_path);
        let mut f = OpenOptions::new().write(true).create_new(true).open(&tmp)?;
        f.write_all(META_MAGIC)?;
        f.write_all(&[VERSION])?;
        write_string(&mut f, &meta.event_id)?;
        f.write_all(&meta.input_len.to_be_bytes())?;
        match meta.input_digest {
            Some(d) => { f.write_all(&[1])?; f.write_all(&d)?; }
            None => f.write_all(&[0])?,
        }
        write_string(&mut f, &meta.capture_status)?;
        write_string(&mut f, &meta.stage)?;
        write_string(&mut f, &meta.code)?;
        f.sync_all()?;
        fs::rename(&tmp, &final_path)?;
        // Make the renamed metadata entry durable before reporting this stage complete.
        sync_parent_directory(&final_path)?;
        Ok(())
    }

    pub fn durability_barrier(&self, event_id: &str) -> io::Result<()> {
        validate_event_id(event_id)?;
        self.fail(FaultPoint::DurabilityBarrier)?;
        File::open(self.blob_path(event_id))?.sync_all()?;
        File::open(self.meta_path(event_id))?.sync_all()?;
        sync_directory(&self.root.join("blobs"))?;
        sync_directory(&self.root.join("metadata"))?;
        sync_directory(&self.root.join("commits"))?;
        sync_directory(&self.root)?;
        Ok(())
    }

    fn write_commit_marker(&self, event_id: &str) -> io::Result<()> {
        validate_event_id(event_id)?;
        let final_path = self.commit_path(event_id);
        if final_path.exists() {
            return Err(io::Error::new(io::ErrorKind::AlreadyExists, "duplicate commit marker"));
        }
        let tmp = Self::tmp_path(&final_path);
        let mut f = OpenOptions::new().write(true).create_new(true).open(&tmp)?;
        f.write_all(COMMIT_MAGIC_V2)?;
        f.write_all(&[2])?;
        write_string(&mut f, event_id)?;
        f.sync_all()?;
        fs::rename(&tmp, &final_path)?;
        // The marker is the commit point; flush its containing directory before success.
        sync_parent_directory(&final_path)?;
        sync_directory(&self.root)?;
        Ok(())
    }

    /// Complete H-08 persistence transaction. The caller supplies the already
    /// bounded capture bytes; this adapter does not decide retention policy.
    pub fn persist(&self, meta: &FailureMetadata, capture: &[u8]) -> PersistenceOutcome {
        if self.begin(&meta.event_id).is_err() { return PersistenceOutcome::Failed; }
        if self.write_blob(&meta.event_id, capture).is_err() { return PersistenceOutcome::Failed; }
        if self.write_metadata(meta).is_err() { return PersistenceOutcome::Failed; }
        if self.fault == FaultPoint::CommitIndeterminate {
            return PersistenceOutcome::PartialOrIndeterminate;
        }
        if self.durability_barrier(&meta.event_id).is_err() { return PersistenceOutcome::PartialOrIndeterminate; }
        if self.write_commit_marker(&meta.event_id).is_err() { return PersistenceOutcome::PartialOrIndeterminate; }
        if self.fault == FaultPoint::PostCommitIndeterminate {
            return PersistenceOutcome::PartialOrIndeterminate;
        }
        PersistenceOutcome::Persisted
    }

    pub fn reconcile(&self, event_id: &str) -> io::Result<RecoveryClass> {
        if validate_event_id(event_id).is_err() { return Ok(RecoveryClass::CorruptEvidence); }
        let blob = self.blob_path(event_id);
        let meta = self.meta_path(event_id);
        let commit = self.commit_path(event_id);
        let be = blob.exists();
        let me = meta.exists();
        let ce = commit.exists();
        match (be, me, ce) {
            (false, false, false) => Ok(RecoveryClass::Incomplete),
            (true, false, false) => Ok(RecoveryClass::OrphanBlob),
            (false, true, false) => Ok(RecoveryClass::MissingBlob),
            (true, true, false) => Ok(RecoveryClass::UnknownCommit),
            (false, false, true) | (true, false, true) => Ok(RecoveryClass::MissingBlob),
            (false, true, true) => Ok(RecoveryClass::MissingBlob),
            (true, true, true) => {
                let m = match read_metadata(&meta) { Ok(v) => v, Err(_) => return Ok(RecoveryClass::CorruptEvidence) };
                if m.event_id != event_id { return Ok(RecoveryClass::DuplicateConflict); }
                let marker_id = match read_commit_marker(&commit) { Ok(v) => v, Err(_) => return Ok(RecoveryClass::CorruptEvidence) };
                if marker_id != event_id { return Ok(RecoveryClass::DuplicateConflict); }
                let bytes = match read_blob(&blob) { Ok(v) => v, Err(_) => return Ok(RecoveryClass::CorruptEvidence) };
                if bytes.len() as u64 != m.input_len && m.capture_status == "Full" {
                    return Ok(RecoveryClass::DigestMismatch);
                }
                if let Some(expected) = m.input_digest {
                    let actual = digest32(&bytes);
                    if actual != expected { return Ok(RecoveryClass::DigestMismatch); }
                }
                Ok(RecoveryClass::CompleteAndDurable)
            }
        }
    }

    pub fn remove_for_test(&self, event_id: &str) -> io::Result<()> {
        validate_event_id(event_id)?;
        let _ = fs::remove_file(self.blob_path(event_id));
        let _ = fs::remove_file(self.meta_path(event_id));
        let _ = fs::remove_file(self.commit_path(event_id));
        Ok(())
    }
}


/// Flush a directory entry to stable storage where the platform exposes a
/// directory-fsync primitive. Unsupported platforms fail closed rather than
/// claiming a durable commit without an equivalent implementation.
#[cfg(unix)]
fn sync_directory(path: &Path) -> io::Result<()> {
    File::open(path)?.sync_all()
}

#[cfg(not(unix))]
fn sync_directory(_path: &Path) -> io::Result<()> {
    Err(io::Error::new(
        io::ErrorKind::Unsupported,
        "durable directory sync is not implemented for this platform",
    ))
}

fn sync_parent_directory(path: &Path) -> io::Result<()> {
    let parent = path.parent().ok_or_else(|| {
        io::Error::new(io::ErrorKind::InvalidInput, "path has no parent directory")
    })?;
    sync_directory(parent)
}

fn validate_event_id(event_id: &str) -> io::Result<()> {
    if event_id.is_empty() || event_id.len() > 128 || event_id == "." || event_id == ".."
        || event_id.contains('/') || event_id.contains('\\')
        || event_id.chars().any(|c| c.is_control()) {
        return Err(io::Error::new(io::ErrorKind::InvalidInput, "invalid event_id"));
    }
    Ok(())
}

fn read_commit_marker(path: &Path) -> io::Result<String> {
    let mut f = File::open(path)?;
    let mut magic = [0u8; 4]; f.read_exact(&mut magic)?;
    let mut v = [0u8; 1]; f.read_exact(&mut v)?;
    match (&magic, v[0]) {
        (m, 1) if m == COMMIT_MAGIC_V1 => {
            // Legacy v1 markers were unframed. Preserve read compatibility, but
            // require the complete tail to be a valid bounded event identifier.
            let mut tail = Vec::new();
            f.take(129).read_to_end(&mut tail)?;
            let id = String::from_utf8(tail).map_err(|_| io::Error::new(io::ErrorKind::InvalidData, "invalid legacy commit id"))?;
            validate_event_id(&id).map_err(|_| io::Error::new(io::ErrorKind::InvalidData, "invalid legacy commit id"))?;
            Ok(id)
        }
        (m, 2) if m == COMMIT_MAGIC_V2 => {
            let id = read_string(&mut f)?;
            ensure_eof(&mut f)?;
            validate_event_id(&id).map_err(|_| io::Error::new(io::ErrorKind::InvalidData, "invalid commit id"))?;
            Ok(id)
        }
        _ => Err(io::Error::new(io::ErrorKind::InvalidData, "bad commit marker version")),
    }
}

fn write_string(w: &mut impl Write, s: &str) -> io::Result<()> {
    let b = s.as_bytes();
    if b.len() > u32::MAX as usize { return Err(io::Error::new(io::ErrorKind::InvalidInput, "string too long")); }
    w.write_all(&(b.len() as u32).to_be_bytes())?;
    w.write_all(b)
}

fn read_string(r: &mut impl Read) -> io::Result<String> {
    let mut n = [0u8; 4]; r.read_exact(&mut n)?;
    let len = u32::from_be_bytes(n) as usize;
    if len > MAX_STRING_BYTES { return Err(io::Error::new(io::ErrorKind::InvalidData, "string exceeds parser bound")); }
    let mut b = vec![0u8; len]; r.read_exact(&mut b)?;
    String::from_utf8(b).map_err(|_| io::Error::new(io::ErrorKind::InvalidData, "invalid utf8"))
}

fn read_blob(path: &Path) -> io::Result<Vec<u8>> {
    let mut f = File::open(path)?; let mut magic = [0u8; 4]; f.read_exact(&mut magic)?;
    if &magic != BLOB_MAGIC { return Err(io::Error::new(io::ErrorKind::InvalidData, "bad blob magic")); }
    let mut v = [0u8; 1]; f.read_exact(&mut v)?; if v[0] != VERSION { return Err(io::Error::new(io::ErrorKind::InvalidData, "bad blob version")); }
    let mut n = [0u8; 8]; f.read_exact(&mut n)?; let declared = u64::from_be_bytes(n);
    let file_len = f.metadata()?.len();
    let header_len = 13u64;
    if declared > MAX_BLOB_BYTES {
        return Err(io::Error::new(io::ErrorKind::InvalidData, "blob exceeds capture bound"));
    }
    if file_len < header_len || declared != file_len - header_len {
        return Err(io::Error::new(io::ErrorKind::InvalidData, "blob length does not match file length"));
    }
    let len = usize::try_from(declared).map_err(|_| io::Error::new(io::ErrorKind::InvalidData, "blob too large for platform"))?;
    let mut b = vec![0u8; len]; f.read_exact(&mut b)?;
    ensure_eof(&mut f)?;
    Ok(b)
}

fn read_metadata(path: &Path) -> io::Result<FailureMetadata> {
    let mut f = File::open(path)?; let mut magic = [0u8; 4]; f.read_exact(&mut magic)?;
    if &magic != META_MAGIC { return Err(io::Error::new(io::ErrorKind::InvalidData, "bad metadata magic")); }
    let mut v = [0u8; 1]; f.read_exact(&mut v)?; if v[0] != VERSION { return Err(io::Error::new(io::ErrorKind::InvalidData, "bad metadata version")); }
    let event_id = read_string(&mut f)?;
    let mut n = [0u8; 8]; f.read_exact(&mut n)?; let input_len = u64::from_be_bytes(n);
    let mut flag = [0u8; 1]; f.read_exact(&mut flag)?;
    let input_digest = match flag[0] { 1 => { let mut d=[0u8;32]; f.read_exact(&mut d)?; Some(d) }, 0 => None, _ => return Err(io::Error::new(io::ErrorKind::InvalidData, "invalid digest flag")), };
    let capture_status = read_string(&mut f)?;
    let stage = read_string(&mut f)?;
    let code = read_string(&mut f)?;
    ensure_eof(&mut f)?;
    let result = FailureMetadata { event_id, input_len, input_digest, capture_status, stage, code };
    result.validate().map_err(|_| io::Error::new(io::ErrorKind::InvalidData, "invalid metadata fields"))?;
    validate_event_id(&result.event_id).map_err(|_| io::Error::new(io::ErrorKind::InvalidData, "invalid metadata event id"))?;
    Ok(result)
}

fn ensure_eof(r: &mut impl Read) -> io::Result<()> {
    let mut trailing = [0u8; 1];
    match r.read(&mut trailing)? { 0 => Ok(()), _ => Err(io::Error::new(io::ErrorKind::InvalidData, "trailing bytes")) }
}

fn digest32(bytes: &[u8]) -> [u8; 32] {
    // Bind H-08 integrity reconciliation to the archived core primitive.
    l8p_core::crypto::sha3_256(bytes)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::time::{SystemTime, UNIX_EPOCH};

    fn temp_root(label: &str) -> PathBuf {
        let n = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_nanos();
        std::env::temp_dir().join(format!("l8p-h08-{}-{}", label, n))
    }
    fn meta(id: &str, len: usize, digest: Option<[u8;32]>) -> FailureMetadata {
        FailureMetadata { event_id:id.into(), input_len:len as u64, input_digest:digest, capture_status:"Full".into(), stage:"Wire".into(), code:"Truncated".into() }
    }
    fn data() -> Vec<u8> { b"bounded failure evidence".to_vec() }



    #[cfg(not(unix))]
    #[test]
    fn h08_non_unix_directory_sync_fails_closed() {
        let root = temp_root("unsupported-dir-sync");
        let backend = FileBackend::open(&root).unwrap();
        let bytes = data();
        let metadata = meta("unsupported-platform", bytes.len(), Some(digest32(&bytes)));
        assert_ne!(backend.persist(&metadata, &bytes), PersistenceOutcome::Persisted);
        let _ = fs::remove_dir_all(root);
    }

    #[cfg(unix)]
    #[test]
    fn h08_directory_sync_primitive_accepts_existing_directory() {
        let root = temp_root("dirsync");
        fs::create_dir_all(&root).unwrap();
        assert!(sync_directory(&root).is_ok());
        let _ = fs::remove_dir_all(root);
    }

    #[test]
    fn h08_all_public_path_boundaries_reject_unsafe_event_ids() {
        let root = temp_root("path-boundaries");
        let backend = FileBackend::open(&root).unwrap();
        let bytes = data();
        let overlong = "x".repeat(129);
        let unique_escape = format!("../../{}/escape", root.file_name().unwrap().to_string_lossy());
        let bad_ids: Vec<&str> = vec!["", ".", "..", "../outside", "../../outside", &unique_escape, "a/b", "a\\b", "bad\nid", &overlong];

        for id in bad_ids {
            assert!(backend.begin(id).is_err(), "begin accepted {id:?}");
            assert!(backend.write_blob(id, &bytes).is_err(), "write_blob accepted {id:?}");
            assert!(backend.write_metadata(&meta(id, bytes.len(), Some(digest32(&bytes)))).is_err(),
                "write_metadata accepted {id:?}");
            assert!(backend.durability_barrier(id).is_err(), "durability_barrier accepted {id:?}");
            assert_eq!(backend.reconcile(id).unwrap(), RecoveryClass::CorruptEvidence,
                "reconcile did not classify unsafe ID conservatively: {id:?}");
            assert!(backend.remove_for_test(id).is_err(), "remove_for_test accepted {id:?}");
        }
        assert!(!root.join("escape.blob").exists(), "path traversal must not create an escaped blob");
        let _ = fs::remove_dir_all(root);
    }

    #[cfg(unix)]
    #[test] fn h08_durable_commit_is_persisted() {
        let root=temp_root("durable"); let b=FileBackend::open(&root).unwrap(); let d=data();
        let m=meta("e1",d.len(),Some(digest32(&d)));
        assert_eq!(b.persist(&m,&d),PersistenceOutcome::Persisted);
        assert_eq!(b.reconcile("e1").unwrap(),RecoveryClass::CompleteAndDurable);
        let _=fs::remove_dir_all(root);
    }
    #[cfg(unix)]
    #[test] fn h08_indeterminate_requires_reconciliation() {
        let root=temp_root("indeterminate"); let b=FileBackend::with_fault(&root,FaultPoint::CommitIndeterminate).unwrap(); let d=data();
        let m=meta("e2",d.len(),Some(digest32(&d)));
        assert_eq!(b.persist(&m,&d),PersistenceOutcome::PartialOrIndeterminate);
        assert_eq!(b.reconcile("e2").unwrap(),RecoveryClass::UnknownCommit);
        let _=fs::remove_dir_all(root);
    }
    #[cfg(unix)]
    #[test]
    fn h08_post_commit_indeterminate_reconciles_as_durable() {
        let root=temp_root("postcommit"); let b=FileBackend::with_fault(&root,FaultPoint::PostCommitIndeterminate).unwrap(); let d=data();
        let m=meta("e-post",d.len(),Some(digest32(&d)));
        assert_eq!(b.persist(&m,&d),PersistenceOutcome::PartialOrIndeterminate);
        assert_eq!(b.reconcile("e-post").unwrap(),RecoveryClass::CompleteAndDurable);
        let _=fs::remove_dir_all(root);
    }
    #[test] fn h08_faults_never_report_persisted() {
        for (i,fault) in [FaultPoint::Begin,FaultPoint::BlobWrite,FaultPoint::MetadataWrite,FaultPoint::DurabilityBarrier].iter().enumerate() {
            let root=temp_root(&format!("fault{}",i)); let b=FileBackend::with_fault(&root,*fault).unwrap(); let d=data();
            let m=meta("e",d.len(),Some(digest32(&d)));
            let out=b.persist(&m,&d); assert_ne!(out,PersistenceOutcome::Persisted);
            let _=fs::remove_dir_all(root);
        }
    }
    #[cfg(unix)]
    #[test] fn h08_missing_blob_is_not_complete() {
        let root=temp_root("missing"); let b=FileBackend::open(&root).unwrap(); let d=data(); let m=meta("e3",d.len(),Some(digest32(&d)));
        assert_eq!(b.persist(&m,&d),PersistenceOutcome::Persisted);
        fs::remove_file(b.blob_path("e3")).unwrap();
        assert_eq!(b.reconcile("e3").unwrap(),RecoveryClass::MissingBlob);
        let _=fs::remove_dir_all(root);
    }
    #[cfg(unix)]
    #[test] fn h08_duplicate_id_does_not_overwrite() {
        let root=temp_root("duplicate"); let b=FileBackend::open(&root).unwrap(); let d=data(); let m=meta("e4",d.len(),Some(digest32(&d)));
        assert_eq!(b.persist(&m,&d),PersistenceOutcome::Persisted);
        assert_eq!(b.write_blob("e4",b"different" ).unwrap_err().kind(),io::ErrorKind::AlreadyExists);
        assert_eq!(b.reconcile("e4").unwrap(),RecoveryClass::CompleteAndDurable);
        let _=fs::remove_dir_all(root);
    }
}
