# L8P H-08 Cargo Verification Workspace v0.3

**Status:** disposable verification workspace; not merged and not release-certified.  
**Constitutional principle:** **Not the Judge — The Witness.**

## What is included

- `L8P_H08_Adapter/`: the previously archived H-08 v0.2 adapter, crash driver, and tests, with a candidate-only change to directory-entry durability ordering and direct public-method event-ID validation.
- `l8p_src/l8p_core/`: extracted unchanged from the frozen Library archive `l8p_core.zip`.
- `.devcontainer/devcontainer.json`: requests the Rust devcontainer image so GitHub Codespaces can provide `rustc` and `cargo` from an Android browser.
- Root Cargo workspace manifest; the adapter's existing dependency path resolves to `../l8p_src/l8p_core`.

Frozen archive identity: 75,366 bytes; SHA-256 `f5415005c0f5ed9dba0e55fc0fb799dc76a3bdb5d67538ec1c61fcd8d6d860ad`.

## Run from the Codespaces terminal

Run each command separately and retain its full output and exit status:

```bash
rustc --version
cargo --version
cargo fmt --manifest-path L8P_H08_Adapter/Cargo.toml --package l8p_h08_adapter -- --check
cargo clippy -p l8p_h08_adapter --all-targets -- -D warnings
cargo test -p l8p_h08_adapter
cargo test -p l8p_core
cargo test -p l8p_core --features reference-signer
```

The formatter and Clippy command are scoped to the H-08 adapter so they do not rewrite or lint the frozen core as the candidate. Run all tests even if an earlier gate fails, and record each command and exit code. Do not apply formatter output to `l8p_src/l8p_core`. The filesystem/crash integration tests are Unix-gated; non-Unix builds intentionally fail closed and include a dedicated negative test.

## Important boundaries

- The candidate source hash is recorded in `SHA256SUMS` and in the review report. Run `bash scripts/verify_hashes.sh` to check the archived core, archived H-08 base, candidate source, and patch hashes. Use `bash scripts/run_gates.sh` to run the gates and save each command output and exit status under `evidence/runs/`.
- From Android, use GitHub Codespaces: upload this ZIP to a temporary branch, open a Codespace on that branch, extract the ZIP at the repository root, then rebuild the container. The exact browser steps are in `ANDROID_CODESPACES_RUNBOOK.md` in this ZIP and in the standalone runbook artifact provided with the project files.

This workspace does not wire H-08 into production admission. `CompleteAndDurable` remains a persistence/recovery classification, not `Admitted`.
- Directory-entry sync is implemented only for Unix. Non-Unix platforms fail closed until a supported equivalent is implemented and tested.
- Initial directory-creation durability, target filesystem/power-loss testing, and full RC gates remain open.
- Do not call this a passing build until the Rust commands above have actually run in this workspace.
