#!/usr/bin/env bash
set -u
cd "$(dirname "$0")/.."
run_id="$(date -u +%Y%m%dT%H%M%SZ)"
out="evidence/runs/$run_id"
mkdir -p "$out"
failures=0

run_gate() {
  local name="$1"; shift
  local log="$out/$name.log"
  local exit_file="$out/$name.exit"
  {
    printf '$'
    printf ' %q' "$@"
    printf '\n'
    "$@"
  } >"$log" 2>&1
  local status=$?
  printf '%s\n' "$status" >"$exit_file"
  cat "$log"
  printf '%s: exit %s\n' "$name" "$status"
  if [ "$status" -ne 0 ]; then failures=$((failures + 1)); fi
}

run_gate platform bash -lc 'uname -a; cat /etc/os-release; df -T . | head -n 2'
run_gate hashes bash scripts/verify_hashes.sh
run_gate rustc-version rustc --version
run_gate cargo-version cargo --version
run_gate adapter-format cargo fmt --manifest-path L8P_H08_Adapter/Cargo.toml --package l8p_h08_adapter -- --check
run_gate adapter-clippy cargo clippy -p l8p_h08_adapter --all-targets -- -D warnings
run_gate adapter-tests cargo test -p l8p_h08_adapter
run_gate core-default-tests cargo test -p l8p_core
run_gate core-reference-signer-tests cargo test -p l8p_core --features reference-signer

printf 'run_id=%s\nfailures=%s\n' "$run_id" "$failures" | tee "$out/SUMMARY.txt"
if [ "$failures" -gt 0 ]; then exit 1; fi
exit 0
