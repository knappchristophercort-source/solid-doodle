# L8P H1.3: Failure Preservation (v0.1, IMPLEMENTED)

Status: implemented in `src/failure/`, execution evidence in `h1_execution_evidence.txt`.
Provenance: drafted and implemented in one pass after the H1.1/H1.2 rebuild. No ratified source exists, so every design decision below is a proposal for review.

## 1. Purpose
H1.1 and H1.2 decide admissibility. H1.3 decides what survives a rejection: every rejected input leaves exactly one tamper-evident, bounded, deterministic record, so the reason an input was refused can be audited later without keeping (or trusting) the input.

## 2. Non-goals
- No signature, chain-of-custody or Level checks (H1.4+).
- No wall-clock timestamps (records are a pure function of the input sequence).
- No persistence or transport. The log lives in memory; `LogSnapshot` is the export surface.
- No BLAKE3. Digests are SHA3-256 (the L8 fallback hash); the primary hash is deferred.

## 3. Record (`FailureRecord`)
`seq`, `kind` (stage + code), `offset` (wire failures), `path` (structure failures, truncated to `max_path`), `input_len`, `input_digest` (SHA3-256 over the FULL input), `capture` (first `max_capture` bytes, may be 0), `prev_digest`, `digest`.
`digest = SHA3-256(length-prefixed preimage of every other field)`. The preimage layout is local to this log and is not an L8 wire format.

## 4. Safety invariants
- K1 Every rejection produces exactly one record; `seq` is consecutive from 0.
- K2 Memory is bounded: at most `max_records` retained, each capture at most `max_capture`, each path at most `max_path`.
- K3 The digest covers the full input, so two inputs sharing a captured prefix are still distinguishable.
- K4 Records form a hash chain from a genesis anchor; any edit, deletion or reorder inside the retained window fails `verify()`.
- K5 Deterministic: identical input sequences produce identical records and head digest.
- K6 A rejection never yields a value; an acceptance never writes a record.
- K7 Eviction is accounted: `retained + evicted == total_rejected`, the eviction anchor lets the retained window verify, lifetime per-code counters survive eviction.
- K8 Total: no input or configuration (including zero limits) panics.

## 5. Known limits (documented, not hidden)
- Tail truncation or a wholesale consistent rewrite is undetectable from the log alone. Detection requires an externally held head digest (`verify_against_head`). Natural next step: publish the head as an L8 `anomaly` attestation and witness it.
- Captured bytes may contain sensitive data. `max_capture = 0` keeps only the digest.
- Hashing is linear in the input the caller already holds in memory.

## 6. Test matrix
16 named tests h1_3_01..16 plus mutation checks run during the build: digest-over-capture-only, unlinked chain, and unaccounted eviction were each injected and each caught.

## 7. Open items needing a decision
1. Should failure records be emitted as L8 `anomaly` attestations (signed, witnessable) instead of a local layout?
2. Eviction policy: drop oldest (current) versus refuse-new-and-alarm.
3. Confirm the assumptions carried from H1.1/H1.2 (below).

## 8. Assumptions carried from the rebuild (reconcile against the ratified specs)
- H1.1 failure code names (9) and test numbering (16) are reconstructed, not copied.
- Envelope layout `[u32 BE length][payload]`, map-key order length-first (RFC 7049) versus bytewise (RFC 8949).
- Major type 7: only false/true/null admitted; all floats rejected.
- H1.2 field types for `id` (lowercase UUID text), `prev`/`sig`/`pk`/`auth_sig` (unpadded base64url text), `wit` (array of maps) and `meta.{sentinel,scope,env}` (text) are inferred. Bodies of identity, binding, null, anomaly, deployment and witness claims are checked as text-keyed maps only.
- Not verifiable without the source: the earlier session's crate may have differed in these details.
