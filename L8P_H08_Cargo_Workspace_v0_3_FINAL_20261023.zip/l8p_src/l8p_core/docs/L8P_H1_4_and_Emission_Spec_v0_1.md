# L8P H1.4 (signature verification), H1.3 emission and anchored checkpoints, v0.1, IMPLEMENTED

Provenance: drafted and implemented after the H1.1/H1.2 rebuild. No ratified source exists for either, so every item marked PROPOSED is a decision for review.

## H1.4: signature verification (`src/verify`, `src/crypto`)
- Ed25519 verification is hand-implemented (RFC 8032), plus SHA-512 and strict base64url. It matches OpenSSL on 84 cases (RFC vectors, bit flips, S+L malleability, non-canonical keys) and Python-signed attestations verify.
- Strict rules: S < L, canonical y, cofactorless equation compared by point compression. Small-order public keys are NOT rejected (same as OpenSSL).
- Signing payload (PROPOSED): SHA3-256 over the canonical CBOR of the attestation map with `sig`, `auth_sig`, `wit` removed. `encode(decode(x)) == x` is tested for every accepted input, which is what makes re-encoding safe.
- Succession: `pk` must equal `body.next_pk`; `sig` verifies under `pk`; `auth_sig` verifies under `body.prev_pk`.
- Six failure codes (BAD_ENCODING, BAD_KEY_LENGTH, BAD_SIG_LENGTH, KEY_MISMATCH, SIGNATURE_INVALID, AUTH_SIGNATURE_INVALID) join the H1.3 log as a third stage.
- `Gate::new` stays structure-only (H1.3 behavior); `Gate::new_verifying` adds H1.4.
- Not checked: `prev_fp`/`next_fp` (fingerprint definition unknown), witness signatures in `wit`, `prev` chain linkage on ingest, Levels.

## Emission (`src/emit`)
- Each preserved failure becomes a signed L8 `anomaly` attestation. Body (PROPOSED shape): `anomaly_type`, `hash`, `stage`, `code`, `seq`, `input_len`, `input_digest`, `record_digest`, `prev_record_digest`, optional `offset`, `path`.
- Only digests are published. The raw capture never leaves the local log (tested for raw, base64url and hex forms, plus a field allowlist).
- `id`: deterministic version-8 UUID from the record digest (idempotent). Timestamp: caller-supplied (the log stays clock-free). `prev`: SHA3-256 of the previous emitted payload; deletion and reordering break `verify_emitted_chain`.
- Eviction before emission produces one `failure_gap` attestation (from_seq, to_seq, anchor digest). Nothing is dropped silently.
- Signing failure stops the cursor; a retry resumes with an unbroken chain.
- Emitted attestations pass the full verifying gate, and every single-bit flip of an emitted attestation is rejected.

## Anchored checkpoints (`src/emit/checkpoint.rs`)
- `Emitter::emit_checkpoint` publishes a signed `anomaly` attestation (`log_checkpoint`) with `head_digest`, `total_rejected`, `evicted`, `anchor_digest`. It joins the same `prev` chain and does not move the record cursor.
- `parse_checkpoint` runs the full pipeline (wire, structure, signature) and pins the emitter's public key.
- `check_log_against_checkpoint` catches: tail truncation (`Truncated`), wholesale replacement or in-place rewrite with a re-linked chain (`HeadMismatch`), and windows that moved past the checkpoint (`Unverifiable`, not a pass). Records that grew after the checkpoint still verify.
- `check_freshness` rejects rollback (fewer rejections than an accepted checkpoint) and fork (same count, different head).
- Residual limits: an old checkpoint blesses a log truncated back to that point, so verifiers must keep the NEWEST checkpoint they have seen. Whoever controls the emitter key AND the log can still sign a false history from now on; witnessing (`wit`) is the answer and is not implemented. A verifier only learns about tampering once it holds a checkpoint newer than the tampering.

## Anchored checkpoints (`src/emit/checkpoint.rs`)
Closes the H1.3 limitation that tail truncation of the local log is undetectable from the log alone.
- `Emitter::emit_checkpoint` publishes the log head as a signed `anomaly` attestation (`log_checkpoint`: head_digest, total_rejected, evicted, anchor_digest). It shares the `prev` chain and does not move the record cursor. Each checkpoint has a distinct id even for identical log state.
- `parse_checkpoint` runs the full H1.1, H1.2 and H1.4 gate, requires the pinned emitter key, and enforces an exact body schema.
- `check_log_against_checkpoint` detects: truncation (fewer rejections than attested), wholesale replacement, and in-place rewrites even when the attacker recomputes the chain. It handles logs that grew after the checkpoint and evicted windows (record retained, anchor boundary, or `Unverifiable` once the window has moved past).
- `check_freshness`: a verifier must keep the newest checkpoint it has accepted. Rollback (lower count) and fork (same count, different head) are reported. Limit: an old checkpoint alone still blesses a log truncated back to that point; only the newest one closes it.
- Tests: 14 (c01..c14), including a randomized history where every truncation point is rejected. Mutation checks found one weak test (eviction-boundary forgery was caught by the wrong layer); it was strengthened and the mutant is now killed.

## Security notes
- `Signer` is a trait. The crate ships a variable-time reference signer behind the `reference-signer` feature for tests and tooling only. Production must plug in an HSM or vetted constant-time library.
- Hand-rolled cryptography is verified against OpenSSL and mutation-tested, not audited. Treat it as a candidate for replacement by a vetted library at the boundary.
- Tail truncation of the local log is still detectable only against an externally anchored head digest. Checkpoints (above) now provide that anchor; witnessing them is the remaining step.

## Open decisions
1. Confirm or replace the signing-payload definition and the anomaly body shape.
2. BLAKE3 (L8 primary hash) versus SHA3-256 fallback: everything here uses SHA3-256.
3. Fingerprint definition for `prev_fp`/`next_fp`.
4. Where the newest checkpoint is stored and how verifiers obtain it (transport is out of scope here).
5. Whether the emitter identity (`sub`, `pk`) should itself be a chained L8 identity.
