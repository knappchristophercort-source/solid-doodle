use crate::crypto::sha3_256;
use crate::model::ValidationCode;
use crate::verify::SigCode;
use crate::wire::FailureCode;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Stage { Wire = 0, Structure = 1, Signature = 2 }

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum FailureKind {
    Wire(FailureCode),
    Structure(ValidationCode),
    Signature(SigCode),
}

impl FailureKind {
    pub fn stage(&self) -> Stage {
        match self { FailureKind::Wire(_) => Stage::Wire, FailureKind::Structure(_) => Stage::Structure, FailureKind::Signature(_) => Stage::Signature }
    }
    pub fn code_str(&self) -> &'static str {
        match self { FailureKind::Wire(c) => c.as_str(), FailureKind::Structure(c) => c.as_str(), FailureKind::Signature(c) => c.as_str() }
    }
    /// Stable index of the code within its stage's fixed vocabulary.
    pub fn tag(&self) -> u8 {
        match self {
            FailureKind::Wire(c) => FailureCode::ALL.iter().position(|x| x == c).unwrap_or(255) as u8,
            FailureKind::Structure(c) => ValidationCode::ALL.iter().position(|x| x == c).unwrap_or(255) as u8,
            FailureKind::Signature(c) => SigCode::ALL.iter().position(|x| x == c).unwrap_or(255) as u8,
        }
    }
}

pub const GENESIS: [u8; 32] = [0u8; 32];

/// One preserved rejection. No wall-clock time is recorded: records are a pure function of the input sequence (K5).
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct FailureRecord {
    pub seq: u64,
    pub kind: FailureKind,
    pub offset: Option<usize>,
    pub path: Option<String>,
    /// Length of the FULL rejected input.
    pub input_len: u64,
    /// SHA3-256 over the FULL rejected input (not just the captured prefix).
    pub input_digest: [u8; 32],
    /// Bounded raw prefix of the input (may be empty by configuration).
    pub capture: Vec<u8>,
    pub prev_digest: [u8; 32],
    pub digest: [u8; 32],
}

impl FailureRecord {
    /// Unambiguous, length-prefixed local layout. Local to this log; NOT an L8 wire format.
    pub fn digest_preimage(&self) -> Vec<u8> {
        let mut o = Vec::with_capacity(160 + self.capture.len());
        o.push(1u8); // layout version
        o.extend_from_slice(&self.seq.to_be_bytes());
        o.push(self.kind.stage() as u8);
        o.push(self.kind.tag());
        match self.offset { Some(v) => { o.push(1); o.extend_from_slice(&(v as u64).to_be_bytes()); } None => o.push(0) }
        match &self.path {
            Some(p) => { o.push(1); o.extend_from_slice(&(p.len() as u32).to_be_bytes()); o.extend_from_slice(p.as_bytes()); }
            None => o.push(0),
        }
        o.extend_from_slice(&self.input_len.to_be_bytes());
        o.extend_from_slice(&self.input_digest);
        o.extend_from_slice(&(self.capture.len() as u32).to_be_bytes());
        o.extend_from_slice(&self.capture);
        o.extend_from_slice(&self.prev_digest);
        o
    }
    pub fn compute_digest(&self) -> [u8; 32] { sha3_256(&self.digest_preimage()) }
}
