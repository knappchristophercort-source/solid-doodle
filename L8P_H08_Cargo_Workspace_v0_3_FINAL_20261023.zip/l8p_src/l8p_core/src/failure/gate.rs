use super::log::{FailureLog, LogConfig};
use super::record::FailureKind;
use crate::model::{validate, Attestation};
use crate::verify::verify_signatures;
use crate::wire::{decode_envelope, Limits};

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Admission {
    Accepted(Attestation),
    /// The input was rejected and preserved as failure record `seq`. No partially decoded value escapes.
    Rejected { seq: u64 },
}

/// H1.1 + H1.2 composed with H1.3 failure preservation.
pub struct Gate {
    verify_sigs: bool,
    limits: Limits,
    log: FailureLog,
    accepted: u64,
}

impl Gate {
    /// Structure-only gate (H1.1 + H1.2 + H1.3): signatures are NOT checked.
    pub fn new(limits: Limits, cfg: LogConfig) -> Self { Gate { verify_sigs: false, limits, log: FailureLog::new(cfg), accepted: 0 } }
    /// Full gate (adds H1.4): an attestation is admitted only if its signature(s) verify.
    pub fn new_verifying(limits: Limits, cfg: LogConfig) -> Self { Gate { verify_sigs: true, limits, log: FailureLog::new(cfg), accepted: 0 } }
    pub fn log(&self) -> &FailureLog { &self.log }
    pub fn accepted_count(&self) -> u64 { self.accepted }

    pub fn admit(&mut self, bytes: &[u8]) -> Admission {
        let decoded = match decode_envelope(bytes, &self.limits) {
            Ok(v) => v,
            Err(e) => {
                let seq = self.log.record(FailureKind::Wire(e.code), Some(e.offset), None, bytes);
                return Admission::Rejected { seq };
            }
        };
        match validate(&decoded) {
            Ok(a) => {
                if self.verify_sigs {
                    if let Err(e) = verify_signatures(&decoded, &a) {
                        let seq = self.log.record(FailureKind::Signature(e.code), None, Some(e.path), bytes);
                        return Admission::Rejected { seq };
                    }
                }
                self.accepted = self.accepted.saturating_add(1);
                Admission::Accepted(a)
            }
            Err(e) => {
                let seq = self.log.record(FailureKind::Structure(e.code), None, Some(&e.path), bytes);
                Admission::Rejected { seq }
            }
        }
    }
}
