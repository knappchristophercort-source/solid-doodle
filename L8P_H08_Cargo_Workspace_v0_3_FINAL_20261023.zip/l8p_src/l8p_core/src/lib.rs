//! L8P core: H1 production trust boundary (zero runtime dependencies by design).
pub mod wire;
pub mod model;
pub mod crypto;
pub mod failure;
pub mod verify;
pub mod emit;
