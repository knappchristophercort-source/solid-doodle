/// The fixed H1.1 failure vocabulary. Every rejection maps to exactly one code.
/// NOTE: names reconstructed from working notes after a container reset; reconcile
/// against the ratified H1.1 spec text when it is re-uploaded.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum FailureCode {
    EnvelopeOversize,
    Truncated,
    InvalidCbor,
    NonCanonical,
    DuplicateKey,
    DepthExceeded,
    ElementLimitExceeded,
    LengthLimitExceeded,
    BudgetExceeded,
}

impl FailureCode {
    pub const ALL: [FailureCode; 9] = [
        FailureCode::EnvelopeOversize,
        FailureCode::Truncated,
        FailureCode::InvalidCbor,
        FailureCode::NonCanonical,
        FailureCode::DuplicateKey,
        FailureCode::DepthExceeded,
        FailureCode::ElementLimitExceeded,
        FailureCode::LengthLimitExceeded,
        FailureCode::BudgetExceeded,
    ];

    pub fn as_str(&self) -> &'static str {
        match self {
            FailureCode::EnvelopeOversize => "ENVELOPE_OVERSIZE",
            FailureCode::Truncated => "TRUNCATED",
            FailureCode::InvalidCbor => "INVALID_CBOR",
            FailureCode::NonCanonical => "NON_CANONICAL",
            FailureCode::DuplicateKey => "DUPLICATE_KEY",
            FailureCode::DepthExceeded => "DEPTH_EXCEEDED",
            FailureCode::ElementLimitExceeded => "ELEMENT_LIMIT_EXCEEDED",
            FailureCode::LengthLimitExceeded => "LENGTH_LIMIT_EXCEEDED",
            FailureCode::BudgetExceeded => "BUDGET_EXCEEDED",
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct DecodeError {
    pub code: FailureCode,
    /// Byte offset (within the slice handed to the failing layer) where the failure was detected.
    pub offset: usize,
}

impl DecodeError {
    pub fn new(code: FailureCode, offset: usize) -> Self {
        DecodeError { code, offset }
    }
}
