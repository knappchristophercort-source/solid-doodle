use super::decoder::{decode, DecodedValue};
use super::errors::{DecodeError, FailureCode};
use super::limits::Limits;

/// Envelope layout (ASSUMED, pending confirmation): [4-byte big-endian u32 payload length][payload].
/// The declared length is checked against the bound BEFORE any payload handling.
pub fn decode_envelope(bytes: &[u8], limits: &Limits) -> Result<DecodedValue, DecodeError> {
    if bytes.len() < 4 {
        return Err(DecodeError::new(FailureCode::Truncated, bytes.len()));
    }
    let declared = u32::from_be_bytes([bytes[0], bytes[1], bytes[2], bytes[3]]) as usize;
    if declared > limits.max_envelope_bytes {
        return Err(DecodeError::new(FailureCode::EnvelopeOversize, 0));
    }
    let avail = bytes.len() - 4;
    if avail < declared {
        return Err(DecodeError::new(FailureCode::Truncated, bytes.len()));
    }
    if avail > declared {
        return Err(DecodeError::new(FailureCode::InvalidCbor, 4 + declared));
    }
    decode(&bytes[4..4 + declared], limits).map_err(|e| DecodeError::new(e.code, e.offset + 4))
}
