/// Explicit resource bounds. Every bound is checked BEFORE the corresponding allocation.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Limits {
    pub max_envelope_bytes: usize,
    pub max_depth: usize,
    pub max_elements: usize,      // per array / per map (pairs)
    pub max_text_len: usize,      // bytes
    pub max_bytes_len: usize,     // bytes
    pub max_total_items: usize,   // aggregate decode budget across the whole value
}

/// Hard ceiling on depth regardless of configuration, so recursion can never blow the stack.
pub const HARD_MAX_DEPTH: usize = 64;

impl Default for Limits {
    fn default() -> Self {
        Limits {
            max_envelope_bytes: 1 << 20,
            max_depth: 16,
            max_elements: 1024,
            max_text_len: 4096,
            max_bytes_len: 65536,
            max_total_items: 16384,
        }
    }
}

impl Limits {
    pub fn effective_depth(&self) -> usize {
        self.max_depth.min(HARD_MAX_DEPTH)
    }
}
