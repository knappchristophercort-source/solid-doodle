use super::errors::{DecodeError, FailureCode};
use super::limits::Limits;
use std::cmp::Ordering;

/// Untyped, structurally admissible value. No identity/signature/provenance meaning is attached (that is H1.2+).
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum DecodedValue {
    Uint(u64),
    /// Negative integer; the represented value is -1 - n.
    NegInt(u64),
    Bytes(Vec<u8>),
    Text(String),
    Array(Vec<DecodedValue>),
    /// Ordered pairs exactly as they appear on the wire (already verified canonically sorted, no duplicates).
    Map(Vec<(DecodedValue, DecodedValue)>),
    Bool(bool),
    Null,
}

struct Ctx<'a> {
    buf: &'a [u8],
    pos: usize,
    limits: &'a Limits,
    items: usize,
    max_depth: usize,
}

fn err<T>(code: FailureCode, offset: usize) -> Result<T, DecodeError> {
    Err(DecodeError::new(code, offset))
}

/// Canonical CBOR map-key order, length-first (RFC 7049 section 3.9): shorter encoded key first, ties bytewise.
/// NOTE: RFC 8949 recommends bytewise-only; this is an open fork awaiting confirmation.
fn key_order(a: &[u8], b: &[u8]) -> Ordering {
    a.len().cmp(&b.len()).then_with(|| a.cmp(b))
}

/// Decode a bare CBOR payload (no envelope). Deterministic and total: never panics on any input.
pub fn decode(payload: &[u8], limits: &Limits) -> Result<DecodedValue, DecodeError> {
    if payload.len() > limits.max_envelope_bytes {
        return err(FailureCode::EnvelopeOversize, 0);
    }
    let mut c = Ctx { buf: payload, pos: 0, limits, items: 0, max_depth: limits.effective_depth() };
    let v = c.item(0)?;
    if c.pos != payload.len() {
        return err(FailureCode::InvalidCbor, c.pos);
    }
    Ok(v)
}

impl<'a> Ctx<'a> {
    fn remaining(&self) -> usize {
        self.buf.len() - self.pos
    }

    fn take(&mut self, n: usize) -> Result<&'a [u8], DecodeError> {
        if self.remaining() < n {
            return err(FailureCode::Truncated, self.buf.len());
        }
        let s = &self.buf[self.pos..self.pos + n];
        self.pos += n;
        Ok(s)
    }

    /// Returns (major, Some(arg)) or (major, None) for indefinite-length marker (ai == 31).
    fn head(&mut self) -> Result<(u8, Option<u64>), DecodeError> {
        let start = self.pos;
        let b = self.take(1)?[0];
        let major = b >> 5;
        let ai = b & 0x1f;
        let arg = match ai {
            0..=23 => ai as u64,
            24 => {
                let v = self.take(1)?[0] as u64;
                if v < 24 { return err(FailureCode::NonCanonical, start); }
                v
            }
            25 => {
                let s = self.take(2)?;
                let v = u16::from_be_bytes([s[0], s[1]]) as u64;
                if v < 0x100 { return err(FailureCode::NonCanonical, start); }
                v
            }
            26 => {
                let s = self.take(4)?;
                let v = u32::from_be_bytes([s[0], s[1], s[2], s[3]]) as u64;
                if v < 0x1_0000 { return err(FailureCode::NonCanonical, start); }
                v
            }
            27 => {
                let s = self.take(8)?;
                let v = u64::from_be_bytes([s[0], s[1], s[2], s[3], s[4], s[5], s[6], s[7]]);
                if v < 0x1_0000_0000 { return err(FailureCode::NonCanonical, start); }
                v
            }
            28..=30 => return err(FailureCode::InvalidCbor, start),
            _ => return Ok((major, None)), // 31
        };
        Ok((major, Some(arg)))
    }

    fn item(&mut self, depth: usize) -> Result<DecodedValue, DecodeError> {
        let start = self.pos;
        self.items += 1;
        if self.items > self.limits.max_total_items {
            return err(FailureCode::BudgetExceeded, start);
        }
        let first = *self.buf.get(self.pos).ok_or(DecodeError::new(FailureCode::Truncated, self.buf.len()))?;
        if first >> 5 == 7 {
            // Major 7 is handled before generic head parsing: only false/true/null in their 1-byte form are
            // accepted; floats, undefined, break, reserved and 2-byte simple forms are not admitted (INVALID_CBOR),
            // and shortest-form rules for integer arguments do not apply to them.
            self.pos += 1;
            return match first & 0x1f {
                20 => Ok(DecodedValue::Bool(false)),
                21 => Ok(DecodedValue::Bool(true)),
                22 => Ok(DecodedValue::Null),
                _ => err(FailureCode::InvalidCbor, start),
            };
        }
        let (major, arg) = self.head()?;
        match (major, arg) {
            // Indefinite length markers / break
            (2..=5, None) => err(FailureCode::NonCanonical, start),
            (0 | 1 | 6, None) => err(FailureCode::InvalidCbor, start),

            (0, Some(n)) => Ok(DecodedValue::Uint(n)),
            (1, Some(n)) => Ok(DecodedValue::NegInt(n)),

            (2, Some(n)) => {
                if n > self.limits.max_bytes_len as u64 { return err(FailureCode::LengthLimitExceeded, start); }
                let n = n as usize;
                let s = self.take(n)?;
                Ok(DecodedValue::Bytes(s.to_vec()))
            }
            (3, Some(n)) => {
                if n > self.limits.max_text_len as u64 { return err(FailureCode::LengthLimitExceeded, start); }
                let n = n as usize;
                let s = self.take(n)?;
                match std::str::from_utf8(s) {
                    Ok(t) => Ok(DecodedValue::Text(t.to_string())),
                    Err(_) => err(FailureCode::InvalidCbor, start),
                }
            }
            (4, Some(n)) => {
                let nd = depth + 1;
                if nd > self.max_depth { return err(FailureCode::DepthExceeded, start); }
                if n > self.limits.max_elements as u64 { return err(FailureCode::ElementLimitExceeded, start); }
                let n = n as usize;
                let mut v = Vec::with_capacity(n.min(self.remaining()));
                for _ in 0..n {
                    v.push(self.item(nd)?);
                }
                Ok(DecodedValue::Array(v))
            }
            (5, Some(n)) => {
                let nd = depth + 1;
                if nd > self.max_depth { return err(FailureCode::DepthExceeded, start); }
                if n > self.limits.max_elements as u64 { return err(FailureCode::ElementLimitExceeded, start); }
                let n = n as usize;
                let mut pairs: Vec<(DecodedValue, DecodedValue)> = Vec::with_capacity(n.min(self.remaining() / 2));
                let mut prev: Option<(usize, usize)> = None;
                for _ in 0..n {
                    let ks = self.pos;
                    let k = self.item(nd)?;
                    let ke = self.pos;
                    if let Some((ps, pe)) = prev {
                        match key_order(&self.buf[ps..pe], &self.buf[ks..ke]) {
                            Ordering::Equal => return err(FailureCode::DuplicateKey, ks),
                            Ordering::Greater => return err(FailureCode::NonCanonical, ks),
                            Ordering::Less => {}
                        }
                    }
                    prev = Some((ks, ke));
                    let val = self.item(nd)?;
                    pairs.push((k, val));
                }
                Ok(DecodedValue::Map(pairs))
            }
            // All tags rejected: H1.1 recognizes zero extensions.
            (6, Some(_)) => err(FailureCode::NonCanonical, start),
            _ => err(FailureCode::InvalidCbor, start),
        }
    }
}
