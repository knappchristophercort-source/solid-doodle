use super::decoder::DecodedValue;

fn head(major: u8, n: u64, out: &mut Vec<u8>) {
    let m = major << 5;
    if n < 24 { out.push(m | n as u8); }
    else if n < 0x100 { out.push(m | 24); out.push(n as u8); }
    else if n < 0x1_0000 { out.push(m | 25); out.extend_from_slice(&(n as u16).to_be_bytes()); }
    else if n < 0x1_0000_0000 { out.push(m | 26); out.extend_from_slice(&(n as u32).to_be_bytes()); }
    else { out.push(m | 27); out.extend_from_slice(&n.to_be_bytes()); }
}

/// Canonical CBOR encoding (shortest heads, definite lengths). Map pairs are emitted in the order stored:
/// values produced by the H1.1 decoder are already canonically ordered, and removing pairs preserves that order.
/// Property (tested): for every input the decoder accepts, encode(decode(x)) == x.
pub fn encode(v: &DecodedValue) -> Vec<u8> {
    let mut o = Vec::new();
    encode_into(v, &mut o);
    o
}

fn encode_into(v: &DecodedValue, o: &mut Vec<u8>) {
    match v {
        DecodedValue::Uint(n) => head(0, *n, o),
        DecodedValue::NegInt(n) => head(1, *n, o),
        DecodedValue::Bytes(b) => { head(2, b.len() as u64, o); o.extend_from_slice(b); }
        DecodedValue::Text(s) => { head(3, s.len() as u64, o); o.extend_from_slice(s.as_bytes()); }
        DecodedValue::Array(a) => { head(4, a.len() as u64, o); for x in a { encode_into(x, o); } }
        DecodedValue::Map(m) => {
            head(5, m.len() as u64, o);
            for (k, val) in m { encode_into(k, o); encode_into(val, o); }
        }
        DecodedValue::Bool(false) => o.push(0xf4),
        DecodedValue::Bool(true) => o.push(0xf5),
        DecodedValue::Null => o.push(0xf6),
    }
}

/// Build a canonically ordered map (length-first, then bytewise over the encoded key) from unordered pairs.
pub fn canonical_map(mut pairs: Vec<(DecodedValue, DecodedValue)>) -> DecodedValue {
    pairs.sort_by(|a, b| {
        let (ka, kb) = (encode(&a.0), encode(&b.0));
        ka.len().cmp(&kb.len()).then_with(|| ka.cmp(&kb))
    });
    DecodedValue::Map(pairs)
}
