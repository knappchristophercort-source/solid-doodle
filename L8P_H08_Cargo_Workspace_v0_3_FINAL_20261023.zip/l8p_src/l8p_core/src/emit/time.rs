/// Format Unix nanoseconds as RFC 3339 UTC with 9 fractional digits, e.g. 2026-09-19T10:07:54.208079000Z.
pub fn rfc3339_from_unix_ns(ns: u64) -> String {
    let secs = (ns / 1_000_000_000) as i64;
    let frac = ns % 1_000_000_000;
    let days = secs.div_euclid(86_400);
    let sod = secs.rem_euclid(86_400);
    // Howard Hinnant's civil_from_days
    let z = days + 719_468;
    let era = z.div_euclid(146_097);
    let doe = z - era * 146_097;
    let yoe = (doe - doe / 1460 + doe / 36_524 - doe / 146_096) / 365;
    let mut y = yoe + era * 400;
    let doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    let mp = (5 * doy + 2) / 153;
    let d = doy - (153 * mp + 2) / 5 + 1;
    let m = if mp < 10 { mp + 3 } else { mp - 9 };
    if m <= 2 { y += 1; }
    format!("{:04}-{:02}-{:02}T{:02}:{:02}:{:02}.{:09}Z", y, m, d, sod / 3600, (sod % 3600) / 60, sod % 60, frac)
}
