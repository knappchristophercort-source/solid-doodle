//! H1.3 emission: turn preserved failure records into signed L8 `anomaly` attestations.
//!
//! PROPOSED design, pending confirmation:
//! * Only DIGESTS leave the boundary. The raw `capture` bytes stay in the local log and are never published.
//! * The anomaly body shape below is new (no ratified schema was available).
//! * `id` is derived from the record digest (idempotent), `prev` chains emitted attestations by SHA3-256 of the
//!   previous attestation's full payload, and the timestamp is supplied by the caller (the log itself is clock-free).
//! * Records evicted before they could be emitted are announced with one `failure_gap` anomaly, never dropped silently.
pub mod checkpoint;
pub mod time;

use crate::crypto::{encode_b64url, sha3_256};
use crate::failure::{FailureLog, FailureRecord};
use crate::verify::signing_payload;
use crate::wire::{canonical_map, decode_envelope, encode, DecodedValue as V, Limits};
use time::rfc3339_from_unix_ns;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct SignError;

/// Signing capability supplied by the caller (HSM, OS keystore, vetted library). The crate never holds production keys.
pub trait Signer {
    fn public_key(&self) -> [u8; 32];
    fn sign(&self, msg: &[u8]) -> Result<[u8; 64], SignError>;
}

#[cfg(feature = "reference-signer")]
pub struct ReferenceSigner { seed: [u8; 32], pk: [u8; 32] }
#[cfg(feature = "reference-signer")]
impl ReferenceSigner {
    pub fn from_seed(seed: [u8; 32]) -> Self { ReferenceSigner { pk: crate::crypto::ed25519::public_key_from_seed(&seed), seed } }
}
#[cfg(feature = "reference-signer")]
impl Signer for ReferenceSigner {
    fn public_key(&self) -> [u8; 32] { self.pk }
    fn sign(&self, msg: &[u8]) -> Result<[u8; 64], SignError> { Ok(crate::crypto::ed25519::sign_reference(&self.seed, msg)) }
}

#[derive(Clone, Debug)]
pub struct EmitConfig {
    pub subject: String,
    pub sentinel: String,
    pub scope: String,
    pub env: String,
}

impl EmitConfig {
    fn validate(&self) -> Result<(), &'static str> {
        if self.subject.is_empty() || self.subject.len() > 256 { return Err("subject must be 1..=256 bytes"); }
        for s in [&self.sentinel, &self.scope, &self.env] { if s.len() > 4096 { return Err("meta strings limited to 4096 bytes"); } }
        Ok(())
    }
}

#[derive(Debug, Default)]
pub struct EmitBatch {
    /// Complete envelopes ([u32 BE length][canonical CBOR]) ready for transport.
    pub attestations: Vec<Vec<u8>>,
    /// How many of `attestations` are `failure_gap` announcements.
    pub gaps: u64,
    /// Set if signing failed part-way; everything before the failure is still returned and the cursor stops there.
    pub error: Option<SignError>,
}

pub struct Emitter<S: Signer> {
    cfg: EmitConfig,
    signer: S,
    next_seq: u64,
    prev: Option<String>,
}

fn txt(s: &str) -> V { V::Text(s.to_string()) }
fn kvs(pairs: Vec<(&str, V)>) -> V { canonical_map(pairs.into_iter().map(|(k, v)| (txt(k), v)).collect()) }
fn b64(d: &[u8]) -> V { V::Text(encode_b64url(d)) }

/// Deterministic UUID (version 8, RFC 4122 variant bits) from 16 bytes of a digest.
fn uuid_from(d: &[u8]) -> String {
    let mut b = [0u8; 16];
    b.copy_from_slice(&d[..16]);
    b[6] = (b[6] & 0x0f) | 0x80;
    b[8] = (b[8] & 0x3f) | 0x80;
    let h: String = b.iter().map(|x| format!("{:02x}", x)).collect();
    format!("{}-{}-{}-{}-{}", &h[0..8], &h[8..12], &h[12..16], &h[16..20], &h[20..32])
}

impl<S: Signer> Emitter<S> {
    pub fn new(cfg: EmitConfig, signer: S) -> Result<Self, &'static str> {
        cfg.validate()?;
        Ok(Emitter { cfg, signer, next_seq: 0, prev: None })
    }
    pub fn next_seq(&self) -> u64 { self.next_seq }

    fn build(&mut self, id: String, body: V, now_unix_ns: u64) -> Result<Vec<u8>, SignError> {
        let mut fields: Vec<(&str, V)> = vec![
            ("ver", txt("L8/1.0")),
            ("id", V::Text(id)),
            ("sub", txt(&self.cfg.subject)),
            ("claim", kvs(vec![("type", txt("anomaly")), ("body", body)])),
            ("ts_unix_ns", V::Uint(now_unix_ns)),
            ("ts_rfc3339", V::Text(rfc3339_from_unix_ns(now_unix_ns))),
            ("prev", match &self.prev { Some(p) => V::Text(p.clone()), None => V::Null }),
            ("pk", b64(&self.signer.public_key())),
            ("wit", V::Array(vec![])),
            ("meta", kvs(vec![("sentinel", txt(&self.cfg.sentinel)), ("scope", txt(&self.cfg.scope)), ("env", txt(&self.cfg.env))])),
        ];
        let payload = signing_payload(&kvs(fields.clone())).ok_or(SignError)?;
        let sig = self.signer.sign(&payload)?;
        fields.push(("sig", b64(&sig)));
        let body_bytes = encode(&kvs(fields));
        let mut env = (body_bytes.len() as u32).to_be_bytes().to_vec();
        env.extend_from_slice(&body_bytes);
        self.prev = Some(encode_b64url(&sha3_256(&body_bytes)));
        Ok(env)
    }

    fn record_body(r: &FailureRecord) -> V {
        let mut b: Vec<(&str, V)> = vec![
            ("anomaly_type", txt("input_rejected")),
            ("hash", txt("sha3-256")),
            ("stage", txt(match r.kind.stage() {
                crate::failure::Stage::Wire => "wire",
                crate::failure::Stage::Structure => "structure",
                crate::failure::Stage::Signature => "signature",
            })),
            ("code", txt(r.kind.code_str())),
            ("seq", V::Uint(r.seq)),
            ("input_len", V::Uint(r.input_len)),
            ("input_digest", b64(&r.input_digest)),
            ("record_digest", b64(&r.digest)),
            ("prev_record_digest", b64(&r.prev_digest)),
        ];
        if let Some(o) = r.offset { b.push(("offset", V::Uint(o as u64))); }
        if let Some(p) = &r.path { b.push(("path", txt(p))); }
        kvs(b)
    }

    /// Emit a signed checkpoint carrying the log's head digest. It joins the same `prev` chain as the record
    /// attestations and does not move the record cursor. Verifiers pin the emitter key and keep the newest one.
    pub fn emit_checkpoint(&mut self, log: &FailureLog, now_unix_ns: u64) -> Result<Vec<u8>, SignError> {
        let (head, total, evicted, anchor) = (log.head(), log.total_rejected(), log.evicted(), log.anchor());
        let mut pre = head.to_vec();
        pre.extend_from_slice(&total.to_be_bytes());
        pre.extend_from_slice(&evicted.to_be_bytes());
        pre.extend_from_slice(self.prev.as_deref().unwrap_or("").as_bytes()); // unique per chain position
        let id = uuid_from(&sha3_256(&pre));
        let body = kvs(vec![
            ("anomaly_type", txt("log_checkpoint")),
            ("hash", txt("sha3-256")),
            ("head_digest", b64(&head)),
            ("total_rejected", V::Uint(total)),
            ("evicted", V::Uint(evicted)),
            ("anchor_digest", b64(&anchor)),
        ]);
        self.build(id, body, now_unix_ns)
    }

    /// Emit an attestation for every record not yet emitted (plus one gap announcement if records were evicted first).
    /// The log is only read. Deterministic for identical inputs (Ed25519 signatures are deterministic).
    pub fn emit_pending(&mut self, log: &FailureLog, now_unix_ns: u64) -> EmitBatch {
        let mut out = EmitBatch::default();
        if self.next_seq < log.evicted() {
            let (from, to, anchor) = (self.next_seq, log.evicted(), log.anchor());
            let mut pre = anchor.to_vec();
            pre.extend_from_slice(&from.to_be_bytes());
            pre.extend_from_slice(&to.to_be_bytes());
            let id = uuid_from(&sha3_256(&pre));
            let body = kvs(vec![
                ("anomaly_type", txt("failure_gap")),
                ("hash", txt("sha3-256")),
                ("from_seq", V::Uint(from)),
                ("to_seq", V::Uint(to)),
                ("anchor_digest", b64(&anchor)),
            ]);
            match self.build(id, body, now_unix_ns) {
                Ok(e) => { out.attestations.push(e); out.gaps += 1; self.next_seq = to; }
                Err(e) => { out.error = Some(e); return out; }
            }
        }
        let start = self.next_seq;
        for r in log.records().filter(|r| r.seq >= start) {
            match self.build(uuid_from(&r.digest), Self::record_body(r), now_unix_ns) {
                Ok(e) => { out.attestations.push(e); self.next_seq = r.seq + 1; }
                Err(e) => { out.error = Some(e); return out; }
            }
        }
        out
    }
}

/// Check the `prev` links across a sequence of emitted envelopes (first must have `prev = null`).
/// Returns the index of the first broken link. Signatures are NOT checked here (use a verifying Gate).
pub fn verify_emitted_chain(envelopes: &[Vec<u8>]) -> Result<(), usize> {
    let mut expected: Option<String> = None;
    for (i, e) in envelopes.iter().enumerate() {
        let d = decode_envelope(e, &Limits::default()).map_err(|_| i)?;
        let prev = match &d {
            V::Map(p) => p.iter().find(|(k, _)| matches!(k, V::Text(s) if s == "prev")).map(|(_, v)| v.clone()),
            _ => None,
        }.ok_or(i)?;
        let got = match prev { V::Null => None, V::Text(s) => Some(s), _ => return Err(i) };
        if got != expected { return Err(i); }
        expected = Some(encode_b64url(&sha3_256(&e[4..])));
    }
    Ok(())
}
