//! Ed25519 signature VERIFICATION (RFC 8032), hand-implemented for the zero-dependency trust boundary.
//! Verification touches only public data, so variable-time arithmetic is acceptable here.
//! There is deliberately NO signing code in this crate. Checks: S < L (strict), canonical y, cofactorless
//! equation compared via point compression (matches OpenSSL/`cryptography` behavior). Small-order public keys are
//! NOT rejected (documented; the same as OpenSSL).
use super::sha512::sha512;
use std::sync::OnceLock;

type Fe = [u64; 4];
const P: Fe = [0xffff_ffff_ffff_ffed, 0xffff_ffff_ffff_ffff, 0xffff_ffff_ffff_ffff, 0x7fff_ffff_ffff_ffff];
const L: Fe = [0x5812_631a_5cf5_d3ed, 0x14de_f9de_a2f7_9cd6, 0, 0x1000_0000_0000_0000];

const fn exp(lo: u8, hi: u8) -> [u8; 32] {
    let mut e = [0xffu8; 32];
    e[0] = lo; e[31] = hi;
    e
}
const EXP_INV: [u8; 32] = exp(0xeb, 0x7f);      // p - 2
const EXP_P58: [u8; 32] = exp(0xfd, 0x0f);      // (p - 5) / 8
const EXP_SQRTM1: [u8; 32] = exp(0xfb, 0x1f);   // (p - 1) / 4  -> 2^that = sqrt(-1)

fn ge(a: &Fe, b: &Fe) -> bool {
    for i in (0..4).rev() {
        if a[i] != b[i] { return a[i] > b[i]; }
    }
    true
}
fn sub_raw(a: &Fe, b: &Fe) -> Fe {
    let mut r = [0u64; 4];
    let mut br = 0u64;
    for i in 0..4 {
        let (d1, b1) = a[i].overflowing_sub(b[i]);
        let (d2, b2) = d1.overflowing_sub(br);
        r[i] = d2;
        br = (b1 | b2) as u64;
    }
    r
}

fn fe_add(a: &Fe, b: &Fe) -> Fe {
    let mut r = [0u64; 4];
    let mut carry = 0u128;
    for i in 0..4 { let s = a[i] as u128 + b[i] as u128 + carry; r[i] = s as u64; carry = s >> 64; }
    let mut c = carry as u64;
    while c != 0 {
        let mut add = (c as u128) * 38;
        for i in 0..4 { let s = r[i] as u128 + add; r[i] = s as u64; add = s >> 64; }
        c = add as u64;
    }
    r
}
fn fe_sub(a: &Fe, b: &Fe) -> Fe {
    let mut r = [0u64; 4];
    let mut br = 0u64;
    for i in 0..4 {
        let (d1, b1) = a[i].overflowing_sub(b[i]);
        let (d2, b2) = d1.overflowing_sub(br);
        r[i] = d2;
        br = (b1 | b2) as u64;
    }
    while br != 0 {
        let mut sub = 38u64;
        for i in 0..4 { let (d, b) = r[i].overflowing_sub(sub); r[i] = d; sub = b as u64; }
        br = sub;
    }
    r
}
fn fe_mul(a: &Fe, b: &Fe) -> Fe {
    let mut r = [0u64; 8];
    for i in 0..4 {
        let mut carry = 0u128;
        for j in 0..4 {
            let cur = r[i + j] as u128 + (a[i] as u128) * (b[j] as u128) + carry;
            r[i + j] = cur as u64;
            carry = cur >> 64;
        }
        r[i + 4] = carry as u64;
    }
    let mut out = [0u64; 4];
    let mut carry = 0u128;
    for i in 0..4 {
        let cur = r[i] as u128 + (r[i + 4] as u128) * 38 + carry;
        out[i] = cur as u64;
        carry = cur >> 64;
    }
    let mut c = carry as u64;
    while c != 0 {
        let mut add = (c as u128) * 38;
        for i in 0..4 { let s = out[i] as u128 + add; out[i] = s as u64; add = s >> 64; }
        c = add as u64;
    }
    out
}
fn fe_neg(a: &Fe) -> Fe { fe_sub(&[0; 4], a) }
fn fe_canon(a: &Fe) -> Fe {
    let mut v = *a;
    for _ in 0..2 {
        let top = v[3] >> 63;
        v[3] &= 0x7fff_ffff_ffff_ffff;
        let mut add = (top as u128) * 19;
        for i in 0..4 { let s = v[i] as u128 + add; v[i] = s as u64; add = s >> 64; }
    }
    if ge(&v, &P) { v = sub_raw(&v, &P); }
    v
}
fn fe_eq(a: &Fe, b: &Fe) -> bool { fe_canon(a) == fe_canon(b) }
fn fe_to_bytes(a: &Fe) -> [u8; 32] {
    let c = fe_canon(a);
    let mut o = [0u8; 32];
    for i in 0..4 { o[i * 8..i * 8 + 8].copy_from_slice(&c[i].to_le_bytes()); }
    o
}
fn fe_from_bytes(b: &[u8; 32]) -> Fe {
    let mut r = [0u64; 4];
    for i in 0..4 { let mut w = [0u8; 8]; w.copy_from_slice(&b[i * 8..i * 8 + 8]); r[i] = u64::from_le_bytes(w); }
    r
}
fn fe_pow(a: &Fe, e: &[u8; 32]) -> Fe {
    let mut r: Fe = [1, 0, 0, 0];
    for bit in (0..256).rev() {
        r = fe_mul(&r, &r);
        if (e[bit / 8] >> (bit % 8)) & 1 == 1 { r = fe_mul(&r, a); }
    }
    r
}

struct Consts { d: Fe, d2: Fe, sqrtm1: Fe, base: Point }
#[derive(Clone, Copy)]
struct Point { x: Fe, y: Fe, z: Fe, t: Fe }

fn consts() -> &'static Consts {
    static C: OnceLock<Consts> = OnceLock::new();
    C.get_or_init(|| {
        let d = fe_mul(&fe_neg(&[121665, 0, 0, 0]), &fe_pow(&[121666, 0, 0, 0], &EXP_INV));
        let d2 = fe_add(&d, &d);
        let two: Fe = [2, 0, 0, 0];
        let sqrtm1 = fe_pow(&two, &EXP_SQRTM1);
        let mut by = [0x66u8; 32];
        by[0] = 0x58;
        let mut c = Consts { d, d2, sqrtm1, base: Point { x: [0; 4], y: [1, 0, 0, 0], z: [1, 0, 0, 0], t: [0; 4] } };
        // Base point: y = 4/5, x even (sign bit 0), decoded by the same routine used for public keys.
        c.base = decompress_with(&c, &by).expect("base point must decode");
        c
    })
}

fn decompress_with(c: &Consts, bytes: &[u8; 32]) -> Option<Point> {
    let sign = bytes[31] >> 7;
    let mut yb = *bytes;
    yb[31] &= 0x7f;
    let y = fe_from_bytes(&yb);
    if ge(&y, &P) { return None; } // non-canonical y
    let one: Fe = [1, 0, 0, 0];
    let y2 = fe_mul(&y, &y);
    let u = fe_sub(&y2, &one);
    let v = fe_add(&fe_mul(&c.d, &y2), &one);
    let v3 = fe_mul(&fe_mul(&v, &v), &v);
    let v7 = fe_mul(&fe_mul(&v3, &v3), &v);
    let mut x = fe_mul(&fe_mul(&u, &v3), &fe_pow(&fe_mul(&u, &v7), &EXP_P58));
    let vx2 = fe_mul(&v, &fe_mul(&x, &x));
    if fe_eq(&vx2, &u) {
    } else if fe_eq(&vx2, &fe_neg(&u)) {
        x = fe_mul(&x, &c.sqrtm1);
    } else {
        return None;
    }
    let xb = fe_to_bytes(&x);
    let is_zero = xb.iter().all(|b| *b == 0);
    if is_zero && sign == 1 { return None; }
    if (xb[0] & 1) != sign { x = fe_neg(&x); }
    Some(Point { x, y, z: one, t: fe_mul(&x, &y) })
}

fn identity() -> Point { Point { x: [0; 4], y: [1, 0, 0, 0], z: [1, 0, 0, 0], t: [0; 4] } }

fn point_add(c: &Consts, p: &Point, q: &Point) -> Point {
    let a = fe_mul(&fe_sub(&p.y, &p.x), &fe_sub(&q.y, &q.x));
    let b = fe_mul(&fe_add(&p.y, &p.x), &fe_add(&q.y, &q.x));
    let cc = fe_mul(&fe_mul(&p.t, &c.d2), &q.t);
    let zz = fe_mul(&p.z, &q.z);
    let dd = fe_add(&zz, &zz);
    let e = fe_sub(&b, &a);
    let f = fe_sub(&dd, &cc);
    let g = fe_add(&dd, &cc);
    let h = fe_add(&b, &a);
    Point { x: fe_mul(&e, &f), y: fe_mul(&g, &h), t: fe_mul(&e, &h), z: fe_mul(&f, &g) }
}

fn scalar_mul(c: &Consts, s: &[u8; 32], p: &Point) -> Point {
    let mut r = identity();
    for bit in (0..256).rev() {
        r = point_add(c, &r, &r);
        if (s[bit / 8] >> (bit % 8)) & 1 == 1 { r = point_add(c, &r, p); }
    }
    r
}

fn compress(p: &Point) -> [u8; 32] {
    let zi = fe_pow(&p.z, &EXP_INV);
    let x = fe_mul(&p.x, &zi);
    let y = fe_mul(&p.y, &zi);
    let mut out = fe_to_bytes(&y);
    out[31] |= (fe_to_bytes(&x)[0] & 1) << 7;
    out
}

/// 512-bit little-endian integer mod L (bitwise long division; 512 tiny iterations).
fn reduce_mod_l(h: &[u8; 64]) -> [u8; 32] {
    let mut r: Fe = [0; 4];
    for bit in (0..512).rev() {
        // r < L < 2^253, so shifting left by one cannot overflow 256 bits.
        let mut carry = ((h[bit / 8] >> (bit % 8)) & 1) as u64;
        for limb in r.iter_mut() { let nc = *limb >> 63; *limb = (*limb << 1) | carry; carry = nc; }
        if ge(&r, &L) { r = sub_raw(&r, &L); }
    }
    let mut o = [0u8; 32];
    for i in 0..4 { o[i * 8..i * 8 + 8].copy_from_slice(&r[i].to_le_bytes()); }
    o
}

pub fn verify(pk: &[u8; 32], msg: &[u8], sig: &[u8; 64]) -> bool {
    let c = consts();
    let mut r_bytes = [0u8; 32];
    r_bytes.copy_from_slice(&sig[..32]);
    let mut s_bytes = [0u8; 32];
    s_bytes.copy_from_slice(&sig[32..]);
    if ge(&fe_from_bytes(&s_bytes), &L) { return false; } // strict: S must be < L
    let a = match decompress_with(c, pk) { Some(a) => a, None => return false };
    let mut input = Vec::with_capacity(64 + msg.len());
    input.extend_from_slice(&r_bytes);
    input.extend_from_slice(pk);
    input.extend_from_slice(msg);
    let k = reduce_mod_l(&sha512(&input));
    let neg_a = Point { x: fe_neg(&a.x), y: a.y, z: a.z, t: fe_neg(&a.t) };
    let sb = scalar_mul(c, &s_bytes, &c.base);
    let ka = scalar_mul(c, &k, &neg_a);
    compress(&point_add(c, &sb, &ka)) == r_bytes
}

/// 256x256 -> 512-bit schoolbook multiply (little-endian limbs), plus an added 256-bit term.
#[cfg(feature = "reference-signer")]
fn mul_add_512(a: &Fe, b: &Fe, add: &Fe) -> [u8; 64] {
    let mut r = [0u64; 8];
    for i in 0..4 {
        let mut carry = 0u128;
        for j in 0..4 {
            let cur = r[i + j] as u128 + (a[i] as u128) * (b[j] as u128) + carry;
            r[i + j] = cur as u64;
            carry = cur >> 64;
        }
        r[i + 4] = carry as u64;
    }
    let mut carry = 0u128;
    for i in 0..8 {
        let cur = r[i] as u128 + if i < 4 { add[i] as u128 } else { 0 } + carry;
        r[i] = cur as u64;
        carry = cur >> 64;
    }
    let mut o = [0u8; 64];
    for i in 0..8 { o[i * 8..i * 8 + 8].copy_from_slice(&r[i].to_le_bytes()); }
    o
}

/// Public key for a 32-byte seed. REFERENCE ONLY: variable-time, must not hold production secrets.
#[cfg(feature = "reference-signer")]
pub fn public_key_from_seed(seed: &[u8; 32]) -> [u8; 32] {
    let c = consts();
    let h = sha512(seed);
    let mut a = [0u8; 32];
    a.copy_from_slice(&h[..32]);
    a[0] &= 248; a[31] &= 127; a[31] |= 64;
    compress(&scalar_mul(c, &a, &c.base))
}

/// Deterministic Ed25519 signature (RFC 8032). REFERENCE ONLY: variable-time scalar multiplication leaks secret
/// bits through timing. Production signers must implement `emit::Signer` over an HSM / vetted constant-time library.
#[cfg(feature = "reference-signer")]
pub fn sign_reference(seed: &[u8; 32], msg: &[u8]) -> [u8; 64] {
    let c = consts();
    let h = sha512(seed);
    let mut a = [0u8; 32];
    a.copy_from_slice(&h[..32]);
    a[0] &= 248; a[31] &= 127; a[31] |= 64;
    let pk = compress(&scalar_mul(c, &a, &c.base));
    let mut pre = h[32..].to_vec();
    pre.extend_from_slice(msg);
    let r = reduce_mod_l(&sha512(&pre));
    let r_point = compress(&scalar_mul(c, &r, &c.base));
    let mut inp = Vec::with_capacity(64 + msg.len());
    inp.extend_from_slice(&r_point);
    inp.extend_from_slice(&pk);
    inp.extend_from_slice(msg);
    let k = reduce_mod_l(&sha512(&inp));
    let s = reduce_mod_l(&mul_add_512(&fe_from_bytes(&k), &fe_from_bytes(&a), &fe_from_bytes(&r)));
    let mut sig = [0u8; 64];
    sig[..32].copy_from_slice(&r_point);
    sig[32..].copy_from_slice(&s);
    sig
}

#[cfg(test)]
mod tests {
    use super::*;
    fn hex(b: &[u8]) -> String { b.iter().map(|x| format!("{:02x}", x)).collect() }
    #[test] fn curve_constants() {
        let c = consts();
        assert_eq!(hex(&fe_to_bytes(&c.d)), "a3785913ca4deb75abd841414d0a700098e879777940c78c73fe6f2bee6c0352");
        assert_eq!(hex(&fe_to_bytes(&c.sqrtm1)), "b0a00e4a271beec478e42fad0618432fa7d7fb3d99004d2b0bdfc14f8024832b");
        assert!(fe_eq(&fe_mul(&c.sqrtm1, &c.sqrtm1), &fe_neg(&[1, 0, 0, 0])));
        assert_eq!(hex(&compress(&c.base)), "5866666666666666666666666666666666666666666666666666666666666666");
    }
    #[test] fn field_mul_matches_small_cases() {
        let a: Fe = [7, 0, 0, 0]; let b: Fe = [9, 0, 0, 0];
        assert_eq!(fe_to_bytes(&fe_mul(&a, &b))[0], 63);
        let one: Fe = [1, 0, 0, 0];
        assert!(fe_eq(&fe_mul(&a, &fe_pow(&a, &EXP_INV)), &one));
        assert!(fe_eq(&fe_add(&fe_neg(&a), &a), &[0; 4]));
    }
}
