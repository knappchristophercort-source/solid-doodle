//! SHA3-256 (FIPS 202), hand-implemented so the trust boundary stays zero-dependency.
//! This is the L8 *fallback* hash; the BLAKE3 primary is not implemented here (deferred, flagged).

const RC: [u64; 24] = [
    0x0000000000000001, 0x0000000000008082, 0x800000000000808a, 0x8000000080008000,
    0x000000000000808b, 0x0000000080000001, 0x8000000080008081, 0x8000000000008009,
    0x000000000000008a, 0x0000000000000088, 0x0000000080008009, 0x000000008000000a,
    0x000000008000808b, 0x800000000000008b, 0x8000000000008089, 0x8000000000008003,
    0x8000000000008002, 0x8000000000000080, 0x000000000000800a, 0x800000008000000a,
    0x8000000080008081, 0x8000000000008080, 0x0000000080000001, 0x8000000080008008,
];
const ROTC: [u32; 24] = [1, 3, 6, 10, 15, 21, 28, 36, 45, 55, 2, 14, 27, 41, 56, 8, 25, 43, 62, 18, 39, 61, 20, 44];
const PILN: [usize; 24] = [10, 7, 11, 17, 18, 3, 5, 16, 8, 21, 24, 4, 15, 23, 19, 13, 12, 2, 20, 14, 22, 9, 6, 1];

fn keccakf(st: &mut [u64; 25]) {
    for round in 0..24 {
        let mut bc = [0u64; 5];
        for i in 0..5 { bc[i] = st[i] ^ st[i + 5] ^ st[i + 10] ^ st[i + 15] ^ st[i + 20]; }
        for i in 0..5 {
            let t = bc[(i + 4) % 5] ^ bc[(i + 1) % 5].rotate_left(1);
            for j in (0..25).step_by(5) { st[j + i] ^= t; }
        }
        let mut t = st[1];
        for i in 0..24 {
            let j = PILN[i];
            let b = st[j];
            st[j] = t.rotate_left(ROTC[i]);
            t = b;
        }
        for j in (0..25).step_by(5) {
            let mut b = [0u64; 5];
            for i in 0..5 { b[i] = st[j + i]; }
            for i in 0..5 { st[j + i] ^= (!b[(i + 1) % 5]) & b[(i + 2) % 5]; }
        }
        st[0] ^= RC[round];
    }
}

const RATE: usize = 136;

fn absorb_block(st: &mut [u64; 25], block: &[u8]) {
    for i in 0..RATE / 8 {
        let mut w = [0u8; 8];
        w.copy_from_slice(&block[i * 8..i * 8 + 8]);
        st[i] ^= u64::from_le_bytes(w);
    }
    keccakf(st);
}

pub fn sha3_256(data: &[u8]) -> [u8; 32] {
    let mut st = [0u64; 25];
    let mut chunks = data.chunks_exact(RATE);
    for c in &mut chunks { absorb_block(&mut st, c); }
    let rem = chunks.remainder();
    let mut last = [0u8; RATE];
    last[..rem.len()].copy_from_slice(rem);
    last[rem.len()] ^= 0x06;
    last[RATE - 1] ^= 0x80;
    absorb_block(&mut st, &last);
    let mut out = [0u8; 32];
    for i in 0..4 { out[i * 8..i * 8 + 8].copy_from_slice(&st[i].to_le_bytes()); }
    out
}

pub fn hex(d: &[u8]) -> String {
    d.iter().map(|b| format!("{:02x}", b)).collect()
}
