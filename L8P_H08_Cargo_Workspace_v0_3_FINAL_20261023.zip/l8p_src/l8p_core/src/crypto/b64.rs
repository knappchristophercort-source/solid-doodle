/// Strict unpadded base64url decode. Rejects padding, non-alphabet bytes, impossible lengths,
/// and non-zero trailing bits (so each byte string has exactly one accepted encoding).
pub fn decode_b64url(s: &str) -> Option<Vec<u8>> {
    let b = s.as_bytes();
    if b.len() % 4 == 1 { return None; }
    let val = |c: u8| -> Option<u32> {
        Some(match c {
            b'A'..=b'Z' => (c - b'A') as u32,
            b'a'..=b'z' => (c - b'a' + 26) as u32,
            b'0'..=b'9' => (c - b'0' + 52) as u32,
            b'-' => 62,
            b'_' => 63,
            _ => return None,
        })
    };
    let mut out = Vec::with_capacity(b.len() * 3 / 4);
    let mut acc: u32 = 0;
    let mut bits = 0u32;
    for &c in b {
        acc = (acc << 6) | val(c)?;
        bits += 6;
        if bits >= 8 { bits -= 8; out.push((acc >> bits) as u8); acc &= (1 << bits) - 1; }
    }
    if acc != 0 { return None; } // non-canonical trailing bits
    Some(out)
}

pub fn encode_b64url(d: &[u8]) -> String {
    const A: &[u8; 64] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
    let mut s = String::new();
    let (mut acc, mut bits) = (0u32, 0u32);
    for &x in d {
        acc = (acc << 8) | x as u32; bits += 8;
        while bits >= 6 { bits -= 6; s.push(A[((acc >> bits) & 63) as usize] as char); acc &= (1 << bits) - 1; }
    }
    if bits > 0 { s.push(A[((acc << (6 - bits)) & 63) as usize] as char); }
    s
}
