#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum ValidationCode {
    NotAMap,
    MissingField,
    UnknownField,
    WrongType,
    InvalidValue,
    UnknownClaimType,
    ConditionalField,
}

impl ValidationCode {
    pub const ALL: [ValidationCode; 7] = [
        ValidationCode::NotAMap,
        ValidationCode::MissingField,
        ValidationCode::UnknownField,
        ValidationCode::WrongType,
        ValidationCode::InvalidValue,
        ValidationCode::UnknownClaimType,
        ValidationCode::ConditionalField,
    ];
    pub fn as_str(&self) -> &'static str {
        match self {
            ValidationCode::NotAMap => "NOT_A_MAP",
            ValidationCode::MissingField => "MISSING_FIELD",
            ValidationCode::UnknownField => "UNKNOWN_FIELD",
            ValidationCode::WrongType => "WRONG_TYPE",
            ValidationCode::InvalidValue => "INVALID_VALUE",
            ValidationCode::UnknownClaimType => "UNKNOWN_CLAIM_TYPE",
            ValidationCode::ConditionalField => "CONDITIONAL_FIELD",
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ValidationError {
    pub code: ValidationCode,
    /// Dotted path of the offending field, e.g. "claim.body.reason".
    pub path: String,
}

impl ValidationError {
    pub fn new(code: ValidationCode, path: impl Into<String>) -> Self {
        ValidationError { code, path: path.into() }
    }
}
