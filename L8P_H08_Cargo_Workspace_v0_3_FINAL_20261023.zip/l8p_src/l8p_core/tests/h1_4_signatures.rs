mod common;
mod h1_4_fixtures;
use h1_4_fixtures::FIXTURES;
use l8p_core::crypto::{decode_b64url, encode_b64url};
use l8p_core::failure::*;
use l8p_core::model::validate;
use l8p_core::verify::{signing_payload, verify_signatures, SigCode as S};
use l8p_core::wire::{decode, decode_envelope, encode, DecodedValue, Limits};

fn unhex(s: &str) -> Vec<u8> { (0..s.len()).step_by(2).map(|i| u8::from_str_radix(&s[i..i + 2], 16).unwrap()).collect() }
fn fx(name: &str) -> Vec<u8> { unhex(FIXTURES.iter().find(|f| f.0 == name).unwrap_or_else(|| panic!("no fixture {}", name)).1) }
fn check(name: &str) -> Result<(), S> {
    let bytes = fx(name);
    let d = decode_envelope(&bytes, &Limits::default()).expect("fixture must be wire-valid");
    let a = validate(&d).expect("fixture must be structurally valid");
    verify_signatures(&d, &a).map_err(|e| e.code)
}
fn verifying_gate() -> Gate { Gate::new_verifying(Limits::default(), LogConfig::default()) }

#[test] fn h1_4_01_valid_identity_signature_from_independent_signer() { assert_eq!(check("identity_valid"), Ok(())); }
#[test] fn h1_4_02_valid_dual_signed_succession() { assert_eq!(check("succession_valid"), Ok(())); }
#[test] fn h1_4_03_tampered_content_rejected() {
    assert_eq!(check("tampered_sub"), Err(S::SignatureInvalid));
    assert_eq!(check("tampered_ts"), Err(S::SignatureInvalid));
}
#[test] fn h1_4_04_signature_by_wrong_key_rejected() { assert_eq!(check("wrong_key"), Err(S::SignatureInvalid)); }
#[test] fn h1_4_05_succession_signature_roles_are_not_interchangeable() {
    // sig must come from the NEW key and auth_sig from the OLD key; swapping them must fail on `sig` first.
    assert_eq!(check("succession_sigs_swapped"), Err(S::SignatureInvalid));
}
#[test] fn h1_4_06_succession_pk_must_equal_body_next_pk() { assert_eq!(check("succession_pk_mismatch"), Err(S::KeyMismatch)); }
#[test] fn h1_4_07_succession_auth_sig_must_be_old_key() { assert_eq!(check("succession_auth_wrong_key"), Err(S::AuthSignatureInvalid)); }
#[test] fn h1_4_08_length_faults() {
    assert_eq!(check("sig_63_bytes"), Err(S::BadSigLength));
    assert_eq!(check("pk_33_bytes"), Err(S::BadKeyLength));
}
#[test] fn h1_4_09_witness_array_is_outside_the_signed_payload() {
    // Adding witnesses after signing must not invalidate the attestation's own signature.
    assert_eq!(check("wit_excluded_from_payload"), Ok(()));
    let a = decode_envelope(&fx("identity_valid"), &Limits::default()).unwrap();
    let b = decode_envelope(&fx("wit_excluded_from_payload"), &Limits::default()).unwrap();
    assert_eq!(signing_payload(&a), signing_payload(&b));
}
#[test] fn h1_4_10_signature_malleability_rejected() { assert_eq!(check("s_plus_l_malleated"), Err(S::SignatureInvalid)); }
#[test] fn h1_4_11_noncanonical_base64_tail_rejected_before_verification() {
    // The H1.2 shape check passes; the strict decoder refuses the alternate encoding of the same bytes.
    assert_eq!(check("sig_noncanonical_b64_tail"), Err(S::BadEncoding));
}
#[test] fn h1_4_12_encode_is_exact_inverse_of_decode_on_every_fixture() {
    for (name, hex) in FIXTURES.iter() {
        let b = unhex(hex);
        let payload = &b[4..];
        let d = decode(payload, &Limits::default()).unwrap();
        assert_eq!(encode(&d), payload, "round-trip failed for {}", name);
    }
}
#[test] fn h1_4_13_roundtrip_property_over_fuzzed_accepted_inputs() {
    let mut p = common::Prng(0xABCDEF);
    let base = unhex(&FIXTURES[1].1)[4..].to_vec();
    let (mut accepted, mut total) = (0, 0);
    for _ in 0..4000 {
        let mut m = base.clone();
        for _ in 0..(1 + p.next() % 2) { let i = (p.next() as usize) % m.len(); m[i] = p.next() as u8; }
        total += 1;
        if let Ok(d) = decode(&m, &Limits::default()) { accepted += 1; assert_eq!(encode(&d), m); }
    }
    assert!(accepted > 0 && accepted < total, "fuzz should hit both accepted and rejected inputs ({} / {})", accepted, total);
    // scalar and container edge cases too
    for v in [DecodedValue::Uint(u64::MAX), DecodedValue::NegInt(u64::MAX), DecodedValue::Null, DecodedValue::Text(String::new()), DecodedValue::Array(vec![])] {
        assert_eq!(decode(&encode(&v), &Limits::default()).unwrap(), v);
    }
}
#[test] fn h1_4_14_payload_is_deterministic_and_map_only() {
    let d = decode_envelope(&fx("identity_valid"), &Limits::default()).unwrap();
    assert_eq!(signing_payload(&d), signing_payload(&d));
    assert_eq!(signing_payload(&DecodedValue::Uint(1)), None);
}
#[test] fn h1_4_15_base64url_codec_roundtrip_and_strictness() {
    for n in 0..70usize {
        let d: Vec<u8> = (0..n).map(|i| (i * 31 + 7) as u8).collect();
        assert_eq!(decode_b64url(&encode_b64url(&d)).unwrap(), d);
    }
    assert!(decode_b64url("QQ==").is_none());   // padding
    assert!(decode_b64url("QR").is_none());     // trailing bits set
    assert!(decode_b64url("Q").is_none());      // impossible length
    assert!(decode_b64url("a+b/").is_none());   // standard alphabet
}
#[test] fn h1_4_16_gate_admits_only_verified_and_logs_signature_failures() {
    let mut g = verifying_gate();
    assert!(matches!(g.admit(&fx("identity_valid")), Admission::Accepted(_)));
    assert!(matches!(g.admit(&fx("succession_valid")), Admission::Accepted(_)));
    for n in ["tampered_sub", "wrong_key", "succession_pk_mismatch", "sig_63_bytes", "succession_auth_wrong_key", "sig_noncanonical_b64_tail"] {
        assert!(matches!(g.admit(&fx(n)), Admission::Rejected { .. }), "{}", n);
    }
    assert_eq!(g.accepted_count(), 2);
    assert_eq!(g.log().total_rejected(), 6);
    assert_eq!(g.log().count(FailureKind::Signature(S::SignatureInvalid)), 2);
    assert_eq!(g.log().count(FailureKind::Signature(S::KeyMismatch)), 1);
    assert_eq!(g.log().count(FailureKind::Signature(S::BadSigLength)), 1);
    assert_eq!(g.log().count(FailureKind::Signature(S::AuthSignatureInvalid)), 1);
    assert_eq!(g.log().count(FailureKind::Signature(S::BadEncoding)), 1);
    let r = g.log().records().next().unwrap();
    assert_eq!(r.kind.stage(), Stage::Signature);
    assert_eq!(r.path.as_deref(), Some("sig"));
    assert!(g.log().verify().is_ok());
}
#[test] fn h1_4_17_structure_only_gate_still_admits_unverified() {
    // Backward compatibility with H1.3: the default gate does not look at signatures.
    let mut g = Gate::new(Limits::default(), LogConfig::default());
    assert!(matches!(g.admit(&fx("tampered_sub")), Admission::Accepted(_)));
}
#[test] fn h1_4_18_bit_flip_sweep_over_a_valid_attestation_never_verifies() {
    let good = unhex(&FIXTURES[0].1)[4..].to_vec();
    let mut verified_clean = 0;
    for i in 0..good.len() {
        for bit in [0u8, 3, 7] {
            let mut m = good.clone(); m[i] ^= 1 << bit;
            if let Ok(d) = decode(&m, &Limits::default()) {
                if let Ok(a) = validate(&d) { if verify_signatures(&d, &a).is_ok() { verified_clean += 1; } }
            }
        }
    }
    // Only flips inside the excluded `wit` array (empty here) could be neutral; none exist, so nothing may verify.
    assert_eq!(verified_clean, 0, "a mutated attestation verified");
}
#[test] fn h1_4_19_all_signature_codes_reachable_and_preservable() {
    use std::collections::HashSet;
    let mut seen = HashSet::new();
    for n in ["tampered_sub", "succession_pk_mismatch", "succession_auth_wrong_key", "sig_63_bytes", "pk_33_bytes", "sig_noncanonical_b64_tail"] {
        seen.insert(check(n).unwrap_err());
    }
    assert_eq!(seen.len(), S::ALL.len(), "missing {:?}", S::ALL.iter().filter(|c| !seen.contains(c)).collect::<Vec<_>>());
}
