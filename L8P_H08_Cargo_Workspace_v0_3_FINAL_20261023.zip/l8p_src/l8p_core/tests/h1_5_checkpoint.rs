mod common;
use l8p_core::emit::checkpoint::*;
use l8p_core::emit::{verify_emitted_chain, EmitConfig, Emitter, ReferenceSigner, Signer};
use l8p_core::failure::*;
use l8p_core::wire::Limits;

const NOW: u64 = 1_789_000_000_000_000_000;
fn cfg() -> EmitConfig { EmitConfig { subject: "gate-01".into(), sentinel: "h1-gate".into(), scope: "h1.3-failures".into(), env: "test".into() } }
fn signer(seed: u8) -> ReferenceSigner { ReferenceSigner::from_seed([seed; 32]) }
fn pk() -> [u8; 32] { signer(42).public_key() }
fn emitter() -> Emitter<ReferenceSigner> { Emitter::new(cfg(), signer(42)).unwrap() }
fn gate(cap: usize) -> Gate { Gate::new(Limits::default(), LogConfig { max_records: cap, ..LogConfig::default() }) }
fn fail(g: &mut Gate, n: usize, salt: u8) { for i in 0..n { let _ = g.admit(&[salt, i as u8, 1, 2]); } }
fn cp_of(g: &Gate, e: &mut Emitter<ReferenceSigner>) -> Checkpoint { parse_checkpoint(&e.emit_checkpoint(g.log(), NOW).unwrap(), &pk()).unwrap() }
fn relink(snap: &mut LogSnapshot, from: usize) {
    let mut prev = if from == 0 { snap.anchor } else { snap.records[from - 1].digest };
    for r in snap.records.iter_mut().skip(from) { r.prev_digest = prev; r.digest = r.compute_digest(); prev = r.digest; }
    snap.head = prev;
}

#[test] fn c01_checkpoint_is_a_valid_signed_attestation_carrying_the_head() {
    let mut g = gate(64); fail(&mut g, 5, 1);
    let env = emitter().emit_checkpoint(g.log(), NOW).unwrap();
    let mut reader = Gate::new_verifying(Limits::default(), LogConfig::default());
    assert!(matches!(reader.admit(&env), Admission::Accepted(_)));
    let cp = parse_checkpoint(&env, &pk()).unwrap();
    assert_eq!((cp.head, cp.total_rejected, cp.evicted, cp.anchor, cp.ts_unix_ns), (g.log().head(), 5, 0, GENESIS, NOW));
}
#[test] fn c02_honest_log_verifies_against_its_checkpoint() {
    let mut g = gate(64); fail(&mut g, 5, 1);
    let cp = cp_of(&g, &mut emitter());
    assert_eq!(check_log_against_checkpoint(&g.log().snapshot(), &cp), Ok(()));
}
#[test] fn c03_log_that_grew_after_the_checkpoint_still_verifies() {
    let mut g = gate(64); fail(&mut g, 5, 1);
    let cp = cp_of(&g, &mut emitter());
    fail(&mut g, 7, 2);
    assert_eq!(check_log_against_checkpoint(&g.log().snapshot(), &cp), Ok(()));
}
#[test] fn c04_tail_truncation_that_defeated_the_bare_log_is_now_detected() {
    let mut g = gate(64); fail(&mut g, 6, 1);
    let cp = cp_of(&g, &mut emitter());
    let mut t = g.log().snapshot();
    t.records.truncate(3); t.head = t.records.last().unwrap().digest; t.next_seq = 3;
    assert!(t.verify().is_ok(), "precondition: truncation is internally consistent");
    assert_eq!(check_log_against_checkpoint(&t, &cp), Err(LogCheckError::Truncated));
    let mut empty = t.clone(); empty.records.clear(); empty.head = GENESIS; empty.next_seq = 0;
    assert_eq!(check_log_against_checkpoint(&empty, &cp), Err(LogCheckError::Truncated));
}
#[test] fn c05_wholesale_replacement_with_a_different_history_is_detected() {
    let mut g = gate(64); fail(&mut g, 5, 1);
    let cp = cp_of(&g, &mut emitter());
    let mut other = gate(64); fail(&mut other, 5, 9);
    assert!(other.log().verify().is_ok());
    assert_eq!(check_log_against_checkpoint(&other.log().snapshot(), &cp), Err(LogCheckError::HeadMismatch));
}
#[test] fn c06_in_place_rewrite_with_recomputed_chain_is_detected() {
    let mut g = gate(64); fail(&mut g, 6, 1);
    let cp = cp_of(&g, &mut emitter());
    let mut s = g.log().snapshot();
    s.records[2].input_digest[0] ^= 1; relink(&mut s, 2);
    assert!(s.verify().is_ok(), "precondition: attacker re-linked the chain");
    assert_eq!(check_log_against_checkpoint(&s, &cp), Err(LogCheckError::HeadMismatch));
    // also appended history behind the rewrite does not hide it
    let mut s2 = g.log().snapshot(); s2.records[0].offset = Some(99); relink(&mut s2, 0);
    assert_eq!(check_log_against_checkpoint(&s2, &cp), Err(LogCheckError::HeadMismatch));
}
#[test] fn c07_eviction_boundaries() {
    let mut g = gate(3); fail(&mut g, 3, 1);
    let cp = cp_of(&g, &mut emitter());               // total 3, evicted 0
    fail(&mut g, 2, 2);                                // window [2..4], evicted 2: record 2 still retained
    assert_eq!(check_log_against_checkpoint(&g.log().snapshot(), &cp), Ok(()));
    fail(&mut g, 1, 3);                                // evicted 3 == total: checked via the anchor
    assert_eq!(g.log().evicted(), 3);
    assert_eq!(check_log_against_checkpoint(&g.log().snapshot(), &cp), Ok(()));
    let mut forged = g.log().snapshot(); forged.anchor[0] ^= 1; relink(&mut forged, 0);
    assert!(forged.verify().is_ok(), "precondition: forged anchor is internally consistent");
    assert_eq!(check_log_against_checkpoint(&forged, &cp), Err(LogCheckError::HeadMismatch));
    fail(&mut g, 2, 4);                                // window moved past the checkpoint
    assert_eq!(check_log_against_checkpoint(&g.log().snapshot(), &cp), Err(LogCheckError::Unverifiable));
}
#[test] fn c08_checkpoint_from_the_wrong_key_is_refused() {
    let mut g = gate(64); fail(&mut g, 2, 1);
    let mut rogue = Emitter::new(cfg(), signer(7)).unwrap();
    let env = rogue.emit_checkpoint(g.log(), NOW).unwrap();
    assert_eq!(parse_checkpoint(&env, &pk()), Err(CheckpointError::WrongKey));
    assert!(parse_checkpoint(&env, &signer(7).public_key()).is_ok());
}
#[test] fn c09_every_bit_flip_of_a_checkpoint_is_refused() {
    let mut g = gate(64); fail(&mut g, 2, 1);
    let env = emitter().emit_checkpoint(g.log(), NOW).unwrap();
    let mut accepted = 0;
    for i in 0..env.len() { for bit in 0..8 { let mut m = env.clone(); m[i] ^= 1 << bit; if parse_checkpoint(&m, &pk()).is_ok() { accepted += 1; } } }
    assert_eq!(accepted, 0);
}
#[test] fn c10_checkpoints_join_the_chain_and_leave_the_record_cursor_alone() {
    let mut g = gate(64); fail(&mut g, 3, 1);
    let mut e = emitter();
    let mut all = e.emit_pending(g.log(), NOW).attestations;
    let seq_before = e.next_seq();
    all.push(e.emit_checkpoint(g.log(), NOW + 1).unwrap());
    assert_eq!(e.next_seq(), seq_before);
    fail(&mut g, 2, 2);
    all.extend(e.emit_pending(g.log(), NOW + 2).attestations);
    all.push(e.emit_checkpoint(g.log(), NOW + 3).unwrap());
    assert_eq!(verify_emitted_chain(&all), Ok(()));
    let mut reader = Gate::new_verifying(Limits::default(), LogConfig::default());
    for a in &all { assert!(matches!(reader.admit(a), Admission::Accepted(_))); }
}
#[test] fn c11_two_checkpoints_of_identical_state_still_get_distinct_ids_and_bytes() {
    let mut g = gate(64); fail(&mut g, 2, 1);
    let mut e = emitter();
    let (a, b) = (e.emit_checkpoint(g.log(), NOW).unwrap(), e.emit_checkpoint(g.log(), NOW).unwrap());
    assert_ne!(a, b);
    let id = |x: &Vec<u8>| { let d = l8p_core::wire::decode_envelope(x, &Limits::default()).unwrap(); l8p_core::model::validate(&d).unwrap().id };
    assert_ne!(id(&a), id(&b));
    assert_eq!(emitter().emit_checkpoint(g.log(), NOW).unwrap(), emitter().emit_checkpoint(g.log(), NOW).unwrap(), "deterministic per chain position");
}
#[test] fn c12_freshness_rollback_and_fork() {
    let mut g = gate(64); fail(&mut g, 2, 1);
    let old = cp_of(&g, &mut emitter());
    fail(&mut g, 3, 1);
    let new = cp_of(&g, &mut emitter());
    assert_eq!(check_freshness(None, &old), Ok(()));
    assert_eq!(check_freshness(Some(&old), &new), Ok(()));
    assert_eq!(check_freshness(Some(&new), &old), Err(FreshnessError::Rollback));
    assert_eq!(check_freshness(Some(&new), &new), Ok(()));
    let mut forked = new.clone(); forked.head[0] ^= 1;
    assert_eq!(check_freshness(Some(&new), &forked), Err(FreshnessError::Fork));
    // documented limit: an old checkpoint alone happily blesses a log truncated back to that point.
    let mut t = g.log().snapshot(); t.records.truncate(2); t.head = t.records[1].digest; t.next_seq = 2;
    assert_eq!(check_log_against_checkpoint(&t, &old), Ok(()));
    assert_eq!(check_log_against_checkpoint(&t, &new), Err(LogCheckError::Truncated));
}
#[test] fn c13_empty_log_checkpoint_and_body_schema_strictness() {
    let g = gate(8);
    let cp = cp_of(&g, &mut emitter());
    assert_eq!((cp.total_rejected, cp.head), (0, GENESIS));
    assert_eq!(check_log_against_checkpoint(&g.log().snapshot(), &cp), Ok(()));
    // A record-anomaly attestation is validly signed but is not a checkpoint.
    let mut g2 = gate(8); fail(&mut g2, 1, 1);
    let rec = emitter().emit_pending(g2.log(), NOW).attestations.remove(0);
    assert_eq!(parse_checkpoint(&rec, &pk()), Err(CheckpointError::NotACheckpoint));
}
#[test] fn c14_randomized_history_always_verifies_and_random_truncations_never_pass() {
    let mut p = common::Prng(0xC0DE);
    let mut g = gate(1000);
    let mut e = emitter();
    let mut cps = vec![];
    for round in 0..8 {
        fail(&mut g, 1 + (p.next() % 6) as usize, round as u8);
        cps.push(cp_of(&g, &mut e));
    }
    let latest = cps.last().unwrap();
    assert_eq!(check_log_against_checkpoint(&g.log().snapshot(), latest), Ok(()));
    for keep in 0..g.log().retained() {
        let mut t = g.log().snapshot();
        t.records.truncate(keep); t.next_seq = keep as u64;
        t.head = t.records.last().map(|r| r.digest).unwrap_or(GENESIS);
        assert_eq!(check_log_against_checkpoint(&t, latest), Err(LogCheckError::Truncated), "keep {}", keep);
    }
    for w in cps.windows(2) { assert_eq!(check_freshness(Some(&w[0]), &w[1]), Ok(())); }
}
