use l8p_core::crypto::{hex, sha3_256};

#[test] fn nist_empty() { assert_eq!(hex(&sha3_256(b"")), "a7ffc6f8bf1ed76651c14756a061d662f580ff4de43b49fa82d80a4b80f8434a"); }
#[test] fn nist_abc() { assert_eq!(hex(&sha3_256(b"abc")), "3a985da74fe225b2045c172d6bd390bd855f086e3e9d525b46bfe24511431532"); }
#[test] fn differential_vs_python_hashlib_across_rate_boundaries() {
    let cases: [(usize, &str); 10] = [
    (0, "a7ffc6f8bf1ed76651c14756a061d662f580ff4de43b49fa82d80a4b80f8434a"),
    (1, "e3ed56bd086d8958483a12734fa0ae7f5c8bb160ef9092c67e82ed9b19e4c7b2"),
    (3, "fffadd0ae913c0947143ac7c6bf1d512c1b265db8ac52100614bd022ae2412d4"),
    (135, "d9dcf1f98e49a79b0643a9e68fef48079ff8777c5e7e7f93469ded65f192ac71"),
    (136, "743bd32e775ac7387a57d4d574c89ddef5ebcb08bb5cc6b88c55a27b5035cc45"),
    (137, "01d47e8d6dce6e3dcbf1baa6f845b6ace4ef74bd17da8176ecc49bc35dbe5d21"),
    (200, "9da37ea2fb33acd563a014f50d6f7cc225f25577a81d900452b72b5de98f239d"),
    (272, "ddeb5151c079739970e780e6257d0c4d52d83bf82c6aa8d47d5195530b5d5f4b"),
    (273, "ca74f68cfcda3bbd9068ae31dd3156e6df046aeb68e3176e4e17bf1557174553"),
    (1000, "bd8b4d76041e0135e53fab1aaf425c7b1c129d8878ffb64cc31230ccafd7dc7c"),
    ];
    for (n, want) in cases {
        let d: Vec<u8> = (0..n).map(|i| ((i * 7 + 3) % 256) as u8).collect();
        assert_eq!(hex(&sha3_256(&d)), want, "len {}", n);
    }
}
