mod common;
use common::*;
use l8p_core::wire::{decode, decode_envelope, DecodedValue, FailureCode as F, Limits};

fn lim() -> Limits { Limits::default() }
fn code(r: Result<DecodedValue, l8p_core::wire::DecodeError>) -> F { r.expect_err("expected rejection").code }

// ---- 16 named adversarial tests (numbering is this rebuild's own; reconcile with the ratified spec) ----
#[test] fn h1_1_01_oversize_declared_length() {
    let mut b = (u32::MAX).to_be_bytes().to_vec(); b.push(0);
    assert_eq!(code(decode_envelope(&b, &lim())), F::EnvelopeOversize);
}
#[test] fn h1_1_02_envelope_truncated() {
    let mut b = 10u32.to_be_bytes().to_vec(); b.extend_from_slice(&[0, 0, 0]);
    assert_eq!(code(decode_envelope(&b, &lim())), F::Truncated);
    assert_eq!(code(decode_envelope(&[0, 0], &lim())), F::Truncated);
}
#[test] fn h1_1_03_trailing_bytes_after_envelope() {
    let mut b = env(&[0x01]); b.push(0xff);
    assert_eq!(code(decode_envelope(&b, &lim())), F::InvalidCbor);
}
#[test] fn h1_1_04_payload_truncated_mid_item() {
    assert_eq!(code(decode(&[0x82, 0x01], &lim())), F::Truncated);
    assert_eq!(code(decode(&[0x19, 0x01], &lim())), F::Truncated);
    assert_eq!(code(decode(&[0x63, b'a', b'b'], &lim())), F::Truncated);
    assert_eq!(code(decode(&[], &lim())), F::Truncated);
}
#[test] fn h1_1_05_non_shortest_integer() {
    assert_eq!(code(decode(&[0x18, 0x05], &lim())), F::NonCanonical);
    assert_eq!(code(decode(&[0x19, 0x00, 0xff], &lim())), F::NonCanonical);
    assert_eq!(code(decode(&[0x1a, 0x00, 0x00, 0xff, 0xff], &lim())), F::NonCanonical);
    assert_eq!(code(decode(&[0x1b, 0, 0, 0, 0, 0xff, 0xff, 0xff, 0xff], &lim())), F::NonCanonical);
    assert_eq!(code(decode(&[0x38, 0x01], &lim())), F::NonCanonical);
}
#[test] fn h1_1_06_non_shortest_length() {
    assert_eq!(code(decode(&[0x78, 0x01, b'a'], &lim())), F::NonCanonical);
    assert_eq!(code(decode(&[0x98, 0x01, 0x00], &lim())), F::NonCanonical);
}
#[test] fn h1_1_07_indefinite_length_rejected() {
    assert_eq!(code(decode(&[0x5f, 0xff], &lim())), F::NonCanonical);
    assert_eq!(code(decode(&[0x7f, 0xff], &lim())), F::NonCanonical);
    assert_eq!(code(decode(&[0x9f, 0xff], &lim())), F::NonCanonical);
    assert_eq!(code(decode(&[0xbf, 0xff], &lim())), F::NonCanonical);
}
#[test] fn h1_1_08_duplicate_map_key() {
    assert_eq!(code(decode(&[0xa2, 0x61, b'a', 0x01, 0x61, b'a', 0x02], &lim())), F::DuplicateKey);
}
#[test] fn h1_1_09_unsorted_map_keys() {
    assert_eq!(code(decode(&[0xa2, 0x61, b'b', 0x01, 0x61, b'a', 0x02], &lim())), F::NonCanonical);
    // length-first: "aa" (len 2) must come AFTER "b" (len 1)
    assert_eq!(code(decode(&[0xa2, 0x62, b'a', b'a', 0x01, 0x61, b'b', 0x02], &lim())), F::NonCanonical);
}
#[test] fn h1_1_10_depth_bomb() {
    let b = nest(100_000);
    assert_eq!(code(decode(&b, &lim())), F::DepthExceeded);
}
#[test] fn h1_1_11_element_count_bomb() {
    // Declares 2^32 elements with almost no bytes: must reject on the bound, not allocate.
    assert_eq!(code(decode(&[0x9a, 0xff, 0xff, 0xff, 0xff], &lim())), F::ElementLimitExceeded);
    assert_eq!(code(decode(&[0xbb, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff], &lim())), F::ElementLimitExceeded);
}
#[test] fn h1_1_12_length_bomb() {
    assert_eq!(code(decode(&[0x5b, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff], &lim())), F::LengthLimitExceeded);
    assert_eq!(code(decode(&[0x7a, 0x7f, 0xff, 0xff, 0xff], &lim())), F::LengthLimitExceeded);
}
#[test] fn h1_1_13_aggregate_budget() {
    let l = Limits { max_total_items: 100, max_elements: 1000, ..lim() };
    let mut b = vec![0x99, 0x01, 0x2c]; // array of 300
    b.extend(std::iter::repeat(0x01).take(300));
    assert_eq!(code(decode(&b, &l)), F::BudgetExceeded);
}
#[test] fn h1_1_14_invalid_utf8() {
    assert_eq!(code(decode(&[0x62, 0xc3, 0x28], &lim())), F::InvalidCbor);
    assert_eq!(code(decode(&[0x61, 0xff], &lim())), F::InvalidCbor);
}
#[test] fn h1_1_15_tags_rejected() {
    assert_eq!(code(decode(&[0xc0, 0x61, b'x'], &lim())), F::NonCanonical);
    assert_eq!(code(decode(&[0xd8, 0x18, 0x41, 0x00], &lim())), F::NonCanonical);
}
#[test] fn h1_1_16_floats_and_simple_values_rejected() {
    assert_eq!(code(decode(&[0xf9, 0x3c, 0x00], &lim())), F::InvalidCbor);
    assert_eq!(code(decode(&[0xfa, 0, 0, 0, 0], &lim())), F::InvalidCbor);
    assert_eq!(code(decode(&[0xfb, 0, 0, 0, 0, 0, 0, 0, 0], &lim())), F::InvalidCbor);
    assert_eq!(code(decode(&[0xf7], &lim())), F::InvalidCbor);          // undefined
    assert_eq!(code(decode(&[0xf0], &lim())), F::InvalidCbor);          // simple(16)
    assert_eq!(code(decode(&[0xf8, 0x14], &lim())), F::InvalidCbor);    // 2-byte form of false
    assert_eq!(code(decode(&[0xff], &lim())), F::InvalidCbor);          // stray break
    assert_eq!(code(decode(&[0x1c], &lim())), F::InvalidCbor);          // reserved ai
}

// ---- Accepting path ----
#[test] fn accepts_canonical_sample_and_scalars() {
    let b = enc(&sample_object());
    let v = decode(&b, &lim()).unwrap();
    match v { DecodedValue::Map(p) => assert_eq!(p.len(), 6), _ => panic!("map") }
    assert_eq!(decode(&[0xf5], &lim()).unwrap(), DecodedValue::Bool(true));
    assert_eq!(decode(&[0x20], &lim()).unwrap(), DecodedValue::NegInt(0));
    assert_eq!(decode(&enc(&t("")), &lim()).unwrap(), DecodedValue::Text(String::new()));
    let e = env(&b);
    assert!(decode_envelope(&e, &lim()).is_ok());
}

// ---- Exact boundaries: limit accepted, limit+1 rejected ----
#[test] fn boundary_depth() {
    let l = Limits { max_depth: 8, ..lim() };
    assert!(decode(&nest(8), &l).is_ok());
    assert_eq!(code(decode(&nest(9), &l)), F::DepthExceeded);
}
#[test] fn boundary_elements() {
    let l = Limits { max_elements: 10, ..lim() };
    let mk = |n: usize| { let mut b = vec![0x80 | n as u8]; b.extend(std::iter::repeat(0x01).take(n)); b };
    assert!(decode(&mk(10), &l).is_ok());
    let mut b = vec![0x8b]; b.extend(std::iter::repeat(0x01).take(11));
    assert_eq!(code(decode(&b, &l)), F::ElementLimitExceeded);
}
#[test] fn boundary_text_and_bytes() {
    let l = Limits { max_text_len: 32, max_bytes_len: 32, ..lim() };
    assert!(decode(&enc(&V::T("a".repeat(32))), &l).is_ok());
    assert_eq!(code(decode(&enc(&V::T("a".repeat(33))), &l)), F::LengthLimitExceeded);
    assert!(decode(&enc(&V::B(vec![0; 32])), &l).is_ok());
    assert_eq!(code(decode(&enc(&V::B(vec![0; 33])), &l)), F::LengthLimitExceeded);
}
#[test] fn boundary_budget() {
    let l = Limits { max_total_items: 11, ..lim() };
    let mk = |n: usize| { let mut b = vec![0x80 | n as u8]; b.extend(std::iter::repeat(0x01).take(n)); b };
    assert!(decode(&mk(10), &l).is_ok());  // 1 array + 10 = 11 items
    assert_eq!(code(decode(&mk(11), &l)), F::BudgetExceeded);
}
#[test] fn boundary_envelope_size() {
    let l = Limits { max_envelope_bytes: 8, ..lim() };
    let ok = env(&[0x01; 8]);
    let bad = { let mut b = 9u32.to_be_bytes().to_vec(); b.extend([0x01; 9]); b };
    assert_eq!(code(decode_envelope(&ok, &l)), F::InvalidCbor); // size OK; 8 bytes = one item + 7 trailing
    assert_eq!(code(decode_envelope(&bad, &l)), F::EnvelopeOversize);
}

// ---- Mutation / truncation / determinism / differential / fuzz ----
#[test] fn truncation_at_every_position_is_determinate() {
    let b = enc(&sample_object());
    for i in 0..b.len() {
        let r1 = decode(&b[..i], &lim());
        let r2 = decode(&b[..i], &lim());
        assert_eq!(r1, r2);
        assert!(r1.is_err(), "prefix of length {} must not decode", i);
    }
}
#[test] fn every_single_bit_flip_is_determinate_and_never_panics() {
    let b = enc(&V::M(vec![(t("a"), V::U(1))]));
    for i in 0..b.len() {
        for bit in 0..8 {
            let mut m = b.clone(); m[i] ^= 1 << bit;
            assert_eq!(decode(&m, &lim()), decode(&m, &lim()));
        }
    }
}
#[test] fn differential_against_python_cbor2_canonical() {
    let hex = "a66161850120410119012c1a00011170616e01617af6626f6bf563766572664c382f312e30666e6573746564a2616b6176626262f4";
    let bytes: Vec<u8> = (0..hex.len()).step_by(2).map(|i| u8::from_str_radix(&hex[i..i + 2], 16).unwrap()).collect();
    assert_eq!(enc(&sample_object()), bytes, "builder must reproduce cbor2 canonical bytes");
    assert!(decode(&bytes, &lim()).is_ok(), "decoder must accept cbor2 canonical output");
}
#[test] fn fuzz_5000_trials_no_panics() {
    let mut p = Prng(0x9E3779B97F4A7C15);
    for _ in 0..5000 {
        let n = (p.next() % 64) as usize;
        let b: Vec<u8> = (0..n).map(|_| p.next() as u8).collect();
        let _ = decode(&b, &lim());
        let _ = decode_envelope(&b, &lim());
    }
}
#[test] fn every_failure_code_reachable() {
    use std::collections::HashSet;
    let cases: Vec<Vec<u8>> = vec![
        (u32::MAX).to_be_bytes().to_vec(),
    ];
    let mut seen: HashSet<F> = HashSet::new();
    for c in cases { if let Err(e) = decode_envelope(&c, &lim()) { seen.insert(e.code); } }
    let l = Limits { max_total_items: 2, ..lim() };
    for (b, li) in [
        (vec![0x82, 0x01], lim()), (vec![0xf7], lim()), (vec![0x18, 0x01], lim()),
        (vec![0xa2, 0x61, b'a', 0x01, 0x61, b'a', 0x02], lim()), (nest(100), lim()),
        (vec![0x9a, 0xff, 0xff, 0xff, 0xff], lim()), (vec![0x7a, 0x7f, 0xff, 0xff, 0xff], lim()),
        (vec![0x83, 1, 2, 3], l),
    ] { if let Err(e) = decode(&b, &li) { seen.insert(e.code); } }
    assert_eq!(seen.len(), F::ALL.len(), "missing: {:?}", F::ALL.iter().filter(|c| !seen.contains(c)).collect::<Vec<_>>());
}
