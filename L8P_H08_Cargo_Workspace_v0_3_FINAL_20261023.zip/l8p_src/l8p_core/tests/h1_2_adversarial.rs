mod common;
use common::*;
use l8p_core::model::{validate, ClaimBody, ClaimType, RevocationReason, SuccessionReason, ValidationCode as C};
use l8p_core::wire::{decode, decode_envelope, DecodedValue, Limits};

fn dv(v: &V) -> DecodedValue { decode(&enc(v), &Limits::default()).expect("fixture must decode") }
fn code(fs: &Fields) -> C { validate(&dv(&f(fs))).expect_err("expected rejection").code }
fn with(mut a: Fields, k: &str, v: V) -> Fields { set(&mut a, k, v); a }
fn without(mut a: Fields, k: &str) -> Fields { del(&mut a, k); a }

#[test] fn h1_2_01_valid_identity() {
    let a = validate(&dv(&f(&identity_att()))).unwrap();
    assert_eq!(a.claim.claim_type, ClaimType::Identity);
    assert_eq!(a.ver, "L8/1.0"); assert_eq!(a.prev, None); assert!(a.auth_sig.is_none());
}
#[test] fn h1_2_02_valid_succession_dual_signed() {
    let a = validate(&dv(&f(&succession_att()))).unwrap();
    assert!(a.auth_sig.is_some());
    match a.claim.body { ClaimBody::Succession(s) => { assert_eq!(s.reason, SuccessionReason::KeyRotation); assert!(s.scope_unchanged); } _ => panic!() }
}
#[test] fn h1_2_03_valid_identity_revocation_both_replaced_by_forms() {
    let a = validate(&dv(&f(&revocation_att()))).unwrap();
    match a.claim.body { ClaimBody::IdentityRevocation(r) => { assert_eq!(r.reason, RevocationReason::UserRequest); assert_eq!(r.replaced_by.as_deref(), Some("agent-c")); } _ => panic!() }
    let mut b = revocation_body(); set(&mut b, "replaced_by", V::Null);
    let mut a2 = identity_att(); set(&mut a2, "claim", f(&kv(vec![("type", t("action")), ("body", f(&b))])));
    match validate(&dv(&f(&a2))).unwrap().claim.body { ClaimBody::IdentityRevocation(r) => assert_eq!(r.replaced_by, None), _ => panic!() }
}
#[test] fn h1_2_04_root_not_a_map() {
    for v in [V::U(1), t("x"), V::A(vec![]), V::Null, V::Bool(true), V::B(vec![1])] {
        assert_eq!(validate(&dv(&v)).unwrap_err().code, C::NotAMap);
    }
}
#[test] fn h1_2_05_every_required_field_omitted() {
    for (k, _) in identity_att() { assert_eq!(code(&without(identity_att(), &k)), C::MissingField, "omitting {}", k); }
}
#[test] fn h1_2_06_unknown_top_level_field() {
    assert_eq!(code(&with(identity_att(), "extra", V::U(1))), C::UnknownField);
}
#[test] fn h1_2_07_wrong_version() {
    for v in ["L8/2.0", "l8/1.0", "", "L8/1.0 "] { assert_eq!(code(&with(identity_att(), "ver", t(v))), C::InvalidValue, "{}", v); }
}
#[test] fn h1_2_08_bad_uuid() {
    for v in ["0190A1B2-C3D4-7E5F-8A9B-0C1D2E3F4A5B", "0190a1b2c3d47e5f8a9b0c1d2e3f4a5b", "0190a1b2-c3d4-7e5f-8a9b-0c1d2e3f4a5", "0190a1b2-c3d4-7e5f-8a9b-0c1d2e3f4a5g", ""] {
        assert_eq!(code(&with(identity_att(), "id", t(v))), C::InvalidValue, "{}", v);
    }
}
#[test] fn h1_2_09_unknown_claim_type() {
    let a = with(identity_att(), "claim", f(&kv(vec![("type", t("wizardry")), ("body", f(&kv(vec![])))])));
    assert_eq!(code(&a), C::UnknownClaimType);
}
#[test] fn h1_2_10_claim_shape() {
    assert_eq!(code(&with(identity_att(), "claim", f(&kv(vec![("type", t("identity"))])))), C::MissingField);
    assert_eq!(code(&with(identity_att(), "claim", f(&kv(vec![("body", f(&kv(vec![])))])))), C::MissingField);
    assert_eq!(code(&with(identity_att(), "claim", f(&kv(vec![("type", t("identity")), ("body", f(&kv(vec![]))), ("x", V::U(1))])))), C::UnknownField);
    assert_eq!(code(&with(identity_att(), "claim", f(&kv(vec![("type", t("identity")), ("body", V::A(vec![]))])))), C::NotAMap);
    assert_eq!(code(&with(identity_att(), "claim", V::U(1))), C::NotAMap);
}
#[test] fn h1_2_11_auth_sig_conditional() {
    assert_eq!(code(&without(succession_att(), "auth_sig")), C::MissingField);
    assert_eq!(code(&with(identity_att(), "auth_sig", t(B64))), C::ConditionalField);
    assert_eq!(code(&with(succession_att(), "auth_sig", t("not base64!"))), C::InvalidValue);
}
#[test] fn h1_2_12_succession_body_faults() {
    let mk = |b: Fields| { let mut a = succession_att(); set(&mut a, "claim", f(&kv(vec![("type", t("succession")), ("body", f(&b))]))); a };
    let mut b = succession_body(); set(&mut b, "reason", t("because"));  assert_eq!(code(&mk(b)), C::InvalidValue);
    let mut b = succession_body(); set(&mut b, "scope_unchanged", t("yes")); assert_eq!(code(&mk(b)), C::WrongType);
    let mut b = succession_body(); del(&mut b, "next_fp"); assert_eq!(code(&mk(b)), C::MissingField);
    let mut b = succession_body(); set(&mut b, "extra", V::U(1)); assert_eq!(code(&mk(b)), C::UnknownField);
    let mut b = succession_body(); set(&mut b, "prev_pk", t("a=b")); assert_eq!(code(&mk(b)), C::InvalidValue);
}
#[test] fn h1_2_13_revocation_body_faults() {
    let mk = |b: Fields| with(identity_att(), "claim", f(&kv(vec![("type", t("action")), ("body", f(&b))])));
    let mut b = revocation_body(); set(&mut b, "reason", t("bored")); assert_eq!(code(&mk(b)), C::InvalidValue);
    let mut b = revocation_body(); set(&mut b, "effective_at", t("tomorrow")); assert_eq!(code(&mk(b)), C::InvalidValue);
    let mut b = revocation_body(); del(&mut b, "replaced_by"); assert_eq!(code(&mk(b)), C::MissingField);
    let mut b = revocation_body(); set(&mut b, "replaced_by", V::U(1)); assert_eq!(code(&mk(b)), C::WrongType);
    let mut b = revocation_body(); set(&mut b, "extra", V::U(1)); assert_eq!(code(&mk(b)), C::UnknownField);
}
#[test] fn h1_2_14_timestamps() {
    for v in ["2026-09-19", "2026-09-19 10:07:54Z", "2026-13-19T10:07:54Z", "2026-09-19T24:00:00Z", "2026-09-19T10:07:54", "2026-09-19T10:07:54.Z", "2026-09-19T10:07:54+0100", "2026-09-19T10:07:54+24:00", ""] {
        assert_eq!(code(&with(identity_att(), "ts_rfc3339", t(v))), C::InvalidValue, "{}", v);
    }
    for v in ["2026-09-19T10:07:54Z", "2026-09-19T10:07:54.5Z", "2026-09-19T10:07:54-07:00", "2026-09-19T10:07:60Z"] {
        assert!(validate(&dv(&f(&with(identity_att(), "ts_rfc3339", t(v))))).is_ok(), "{}", v);
    }
    assert_eq!(code(&with(identity_att(), "ts_unix_ns", t("1"))), C::WrongType);
    assert_eq!(code(&with(identity_att(), "ts_unix_ns", V::N(0))), C::WrongType);
}
#[test] fn h1_2_15_base64url_shape() {
    for v in ["", "abc=", "ab+c", "ab/c", "a", "abcde", "ab cd"] { assert_eq!(code(&with(identity_att(), "sig", t(v))), C::InvalidValue, "{}", v); }
    assert_eq!(code(&with(identity_att(), "pk", V::B(vec![1, 2]))), C::WrongType);
}
#[test] fn h1_2_16_wit_shape() {
    assert_eq!(code(&with(identity_att(), "wit", t("x"))), C::WrongType);
    assert_eq!(code(&with(identity_att(), "wit", V::A(vec![V::U(1)]))), C::NotAMap);
    let ok = with(identity_att(), "wit", V::A(vec![f(&kv(vec![("w", t("x"))]))]));
    assert_eq!(validate(&dv(&f(&ok))).unwrap().wit.len(), 1);
}
#[test] fn h1_2_17_meta_shape() {
    assert_eq!(code(&with(identity_att(), "meta", f(&kv(vec![("sentinel", t("s")), ("env", t("e"))])))), C::MissingField);
    assert_eq!(code(&with(identity_att(), "meta", f(&kv(vec![("sentinel", t("s")), ("scope", t("c")), ("env", t("e")), ("x", t("y"))])))), C::UnknownField);
    assert_eq!(code(&with(identity_att(), "meta", f(&kv(vec![("sentinel", V::U(1)), ("scope", t("c")), ("env", t("e"))])))), C::WrongType);
    assert_eq!(code(&with(identity_att(), "meta", V::A(vec![]))), C::NotAMap);
}

// ---- coverage beyond the 17 named ----
#[test] fn every_field_wrong_type() {
    for (k, _) in identity_att() {
        let bad = code(&with(identity_att(), &k, V::B(vec![9])));
        assert!(matches!(bad, C::WrongType | C::NotAMap), "field {} -> {:?}", k, bad);
    }
}
#[test] fn non_text_map_key_rejected() {
    let v = V::M(vec![(V::U(1), V::U(1))]);
    assert_eq!(validate(&dv(&v)).unwrap_err().code, C::WrongType);
}
#[test] fn j7_determinism_and_path_reporting() {
    let a = with(succession_att(), "auth_sig", t("!"));
    let (r1, r2) = (validate(&dv(&f(&a))), validate(&dv(&f(&a))));
    assert_eq!(r1, r2);
    assert_eq!(r1.unwrap_err().path, "auth_sig");
}
#[test] fn envelope_to_typed_end_to_end() {
    let bytes = env(&enc(&f(&succession_att())));
    let d = decode_envelope(&bytes, &Limits::default()).unwrap();
    assert!(validate(&d).is_ok());
}
#[test] fn all_validation_codes_reachable() {
    use std::collections::HashSet;
    let mut seen = HashSet::new();
    let cases: Vec<Fields> = vec![
        with(identity_att(), "ver", t("x")), without(identity_att(), "sig"), with(identity_att(), "x", V::Null),
        with(identity_att(), "sub", V::U(1)), with(identity_att(), "claim", f(&kv(vec![("type", t("zz")), ("body", f(&kv(vec![])))]))),
        with(identity_att(), "auth_sig", t(B64)),
    ];
    for c in cases { seen.insert(code(&c)); }
    seen.insert(validate(&dv(&V::U(1))).unwrap_err().code);
    assert_eq!(seen.len(), C::ALL.len(), "missing {:?}", C::ALL.iter().filter(|c| !seen.contains(c)).collect::<Vec<_>>());
}
#[test] fn panic_resistance_mutated_valid_inputs() {
    let base = enc(&f(&succession_att()));
    let mut p = Prng(0xC0FFEE);
    for _ in 0..5000 {
        let mut m = base.clone();
        for _ in 0..(1 + p.next() % 3) { let i = (p.next() as usize) % m.len(); m[i] = p.next() as u8; }
        if let Ok(d) = decode(&m, &Limits::default()) { let _ = validate(&d); }
    }
}
