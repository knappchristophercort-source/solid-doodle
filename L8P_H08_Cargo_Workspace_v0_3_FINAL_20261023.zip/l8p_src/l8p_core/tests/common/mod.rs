#![allow(dead_code)]
//! Minimal canonical CBOR builder used only to construct test inputs.
#[derive(Clone, Debug)]
pub enum V {
    U(u64),
    N(u64),
    B(Vec<u8>),
    T(String),
    A(Vec<V>),
    M(Vec<(V, V)>),
    Bool(bool),
    Null,
}

pub fn head(major: u8, n: u64, out: &mut Vec<u8>) {
    let m = major << 5;
    if n < 24 { out.push(m | n as u8); }
    else if n < 0x100 { out.push(m | 24); out.push(n as u8); }
    else if n < 0x1_0000 { out.push(m | 25); out.extend_from_slice(&(n as u16).to_be_bytes()); }
    else if n < 0x1_0000_0000 { out.push(m | 26); out.extend_from_slice(&(n as u32).to_be_bytes()); }
    else { out.push(m | 27); out.extend_from_slice(&n.to_be_bytes()); }
}

pub fn enc(v: &V) -> Vec<u8> {
    let mut o = Vec::new();
    match v {
        V::U(n) => head(0, *n, &mut o),
        V::N(n) => head(1, *n, &mut o),
        V::B(b) => { head(2, b.len() as u64, &mut o); o.extend_from_slice(b); }
        V::T(s) => { head(3, s.len() as u64, &mut o); o.extend_from_slice(s.as_bytes()); }
        V::A(a) => { head(4, a.len() as u64, &mut o); for x in a { o.extend(enc(x)); } }
        V::M(m) => {
            let mut es: Vec<(Vec<u8>, Vec<u8>)> = m.iter().map(|(k, v)| (enc(k), enc(v))).collect();
            es.sort_by(|a, b| a.0.len().cmp(&b.0.len()).then_with(|| a.0.cmp(&b.0)));
            head(5, es.len() as u64, &mut o);
            for (k, v) in es { o.extend(k); o.extend(v); }
        }
        V::Bool(false) => o.push(0xf4),
        V::Bool(true) => o.push(0xf5),
        V::Null => o.push(0xf6),
    }
    o
}

pub fn t(s: &str) -> V { V::T(s.to_string()) }
pub fn env(payload: &[u8]) -> Vec<u8> {
    let mut o = (payload.len() as u32).to_be_bytes().to_vec();
    o.extend_from_slice(payload);
    o
}
/// Nested arrays `depth` levels deep: [[[...0...]]]
pub fn nest(depth: usize) -> Vec<u8> {
    let mut o = vec![0x81; depth];
    o.push(0x00);
    o
}
pub struct Prng(pub u64);
impl Prng {
    pub fn next(&mut self) -> u64 {
        // xorshift64*
        let mut x = self.0;
        x ^= x >> 12; x ^= x << 25; x ^= x >> 27;
        self.0 = x;
        x.wrapping_mul(0x2545F4914F6CDD1D)
    }
}
pub fn sample_object() -> V {
    V::M(vec![
        (t("ver"), t("L8/1.0")),
        (t("n"), V::U(1)),
        (t("ok"), V::Bool(true)),
        (t("z"), V::Null),
        (t("a"), V::A(vec![V::U(1), V::N(0), V::B(vec![1]), V::U(300), V::U(70000)])),
        (t("nested"), V::M(vec![(t("k"), t("v")), (t("bb"), V::Bool(false))])),
    ])
}

// ---- Attestation fixtures (H1.2+) ----
pub const B64: &str = "Zm9vYmFyYmF6cXV4MTIzNDU2Nzg5MGFiY2RlZg"; // shape-valid base64url
pub fn uuid() -> String { "0190a1b2-c3d4-7e5f-8a9b-0c1d2e3f4a5b".to_string() }
pub type Fields = Vec<(String, V)>;
pub fn f(fields: &Fields) -> V { V::M(fields.iter().map(|(k, v)| (t(k), v.clone())).collect()) }
pub fn set(fs: &mut Fields, k: &str, v: V) {
    if let Some(e) = fs.iter_mut().find(|e| e.0 == k) { e.1 = v; } else { fs.push((k.to_string(), v)); }
}
pub fn del(fs: &mut Fields, k: &str) { fs.retain(|e| e.0 != k); }
pub fn get(fs: &Fields, k: &str) -> V { fs.iter().find(|e| e.0 == k).unwrap().1.clone() }
pub fn kv(pairs: Vec<(&str, V)>) -> Fields { pairs.into_iter().map(|(k, v)| (k.to_string(), v)).collect() }

pub fn identity_att() -> Fields {
    kv(vec![
        ("ver", t("L8/1.0")),
        ("id", V::T(uuid())),
        ("sub", t("agent-a")),
        ("claim", f(&kv(vec![("type", t("identity")), ("body", f(&kv(vec![("name", t("agent-a"))])))]))),
        ("ts_unix_ns", V::U(1_789_000_000_000_000_000)),
        ("ts_rfc3339", t("2026-09-19T10:07:54.208079Z")),
        ("prev", V::Null),
        ("sig", t(B64)),
        ("pk", t(B64)),
        ("wit", V::A(vec![])),
        ("meta", f(&kv(vec![("sentinel", t("s0")), ("scope", t("default")), ("env", t("test"))]))),
    ])
}
pub fn succession_body() -> Fields {
    kv(vec![
        ("prev_pk", t(B64)), ("next_pk", t(B64)), ("prev_fp", t(B64)), ("next_fp", t(B64)),
        ("reason", t("key_rotation")), ("scope_unchanged", V::Bool(true)),
    ])
}
pub fn succession_att() -> Fields {
    let mut a = identity_att();
    set(&mut a, "claim", f(&kv(vec![("type", t("succession")), ("body", f(&succession_body()))])));
    set(&mut a, "auth_sig", t(B64));
    a
}
pub fn revocation_body() -> Fields {
    kv(vec![
        ("action_type", t("identity_revocation")), ("subject", t("agent-a")), ("reason", t("user_request")),
        ("revoked_at", t("2026-09-19T10:07:54Z")), ("effective_at", t("2026-09-20T00:00:00+00:00")),
        ("authorized_by", t("agent-a")), ("replaced_by", t("agent-c")),
    ])
}
pub fn revocation_att() -> Fields {
    let mut a = identity_att();
    set(&mut a, "claim", f(&kv(vec![("type", t("action")), ("body", f(&revocation_body()))])));
    a
}
