mod common;
mod h1_4_fixtures;
use common::Prng;
use h1_4_fixtures::FIXTURES;
use l8p_core::crypto::{encode_b64url, sha3_256};
use l8p_core::emit::{time::rfc3339_from_unix_ns, verify_emitted_chain, EmitConfig, Emitter, ReferenceSigner, SignError, Signer};
use l8p_core::failure::*;
use l8p_core::wire::{decode_envelope, DecodedValue as D, Limits};
use std::cell::Cell;
use std::rc::Rc;

fn unhex(s: &str) -> Vec<u8> { (0..s.len()).step_by(2).map(|i| u8::from_str_radix(&s[i..i + 2], 16).unwrap()).collect() }
fn fx(name: &str) -> Vec<u8> { unhex(FIXTURES.iter().find(|f| f.0 == name).unwrap().1) }
fn cfg() -> EmitConfig { EmitConfig { subject: "gate-01".into(), sentinel: "h1-gate".into(), scope: "h1.3-failures".into(), env: "test".into() } }
fn signer() -> ReferenceSigner { ReferenceSigner::from_seed([42u8; 32]) }
fn emitter() -> Emitter<ReferenceSigner> { Emitter::new(cfg(), signer()).unwrap() }
fn vgate(max_records: usize) -> Gate { Gate::new_verifying(Limits::default(), LogConfig { max_records, ..LogConfig::default() }) }
const NOW: u64 = 1_789_000_000_123_456_789;

/// One failure of each stage, in a verifying gate.
fn mixed_failures() -> Gate {
    let mut g = vgate(1024);
    let mut oversize = u32::MAX.to_be_bytes().to_vec(); oversize.extend_from_slice(b"SECRETSECRET1234");
    let _ = g.admit(&oversize);                       // wire
    let _ = g.admit(&[0, 0, 0, 1, 0x01]);             // structure (root not a map)
    let _ = g.admit(&fx("tampered_sub"));             // signature
    let _ = g.admit(&fx("succession_pk_mismatch"));   // signature
    g
}
fn body(env: &[u8]) -> Vec<(String, D)> {
    let d = decode_envelope(env, &Limits::default()).unwrap();
    let get = |m: &Vec<(D, D)>, k: &str| m.iter().find(|(x, _)| matches!(x, D::Text(s) if s == k)).map(|(_, v)| v.clone());
    let m = match d { D::Map(m) => m, _ => panic!() };
    match get(&m, "claim").unwrap() {
        D::Map(c) => match get(&c, "body").unwrap() { D::Map(b) => b.into_iter().map(|(k, v)| (match k { D::Text(s) => s, _ => panic!() }, v)).collect(), _ => panic!() },
        _ => panic!(),
    }
}
fn field(b: &[(String, D)], k: &str) -> Option<D> { b.iter().find(|(x, _)| x == k).map(|(_, v)| v.clone()) }

#[test] fn e01_emitted_attestations_pass_the_full_verifying_gate() {
    let g = mixed_failures();
    let mut e = emitter();
    let batch = e.emit_pending(g.log(), NOW);
    assert!(batch.error.is_none());
    assert_eq!(batch.attestations.len(), 4);
    let mut reader = Gate::new_verifying(Limits::default(), LogConfig::default());
    for a in &batch.attestations { assert!(matches!(reader.admit(a), Admission::Accepted(_))); }
    assert_eq!(reader.accepted_count(), 4);
    assert_eq!(reader.log().total_rejected(), 0);
}
#[test] fn e02_body_fields_match_the_preserved_record() {
    let g = mixed_failures();
    let batch = emitter().emit_pending(g.log(), NOW);
    for (rec, att) in g.log().records().zip(batch.attestations.iter()) {
        let b = body(att);
        assert_eq!(field(&b, "anomaly_type"), Some(D::Text("input_rejected".into())));
        assert_eq!(field(&b, "code"), Some(D::Text(rec.kind.code_str().into())));
        assert_eq!(field(&b, "seq"), Some(D::Uint(rec.seq)));
        assert_eq!(field(&b, "input_len"), Some(D::Uint(rec.input_len)));
        assert_eq!(field(&b, "input_digest"), Some(D::Text(encode_b64url(&rec.input_digest))));
        assert_eq!(field(&b, "record_digest"), Some(D::Text(encode_b64url(&rec.digest))));
        assert_eq!(field(&b, "prev_record_digest"), Some(D::Text(encode_b64url(&rec.prev_digest))));
        assert_eq!(field(&b, "offset").is_some(), rec.offset.is_some());
        assert_eq!(field(&b, "path"), rec.path.clone().map(D::Text));
        let stage = match rec.kind.stage() { Stage::Wire => "wire", Stage::Structure => "structure", Stage::Signature => "signature" };
        assert_eq!(field(&b, "stage"), Some(D::Text(stage.into())));
    }
}
#[test] fn e03_attestation_chain_links_and_detects_deletion_and_reorder() {
    let g = mixed_failures();
    let a = emitter().emit_pending(g.log(), NOW).attestations;
    assert_eq!(verify_emitted_chain(&a), Ok(()));
    let mut del = a.clone(); del.remove(1);
    assert_eq!(verify_emitted_chain(&del), Err(1));
    let mut sw = a.clone(); sw.swap(1, 2);
    assert!(verify_emitted_chain(&sw).is_err());
    assert!(verify_emitted_chain(&a[1..]).is_err(), "a chain must start at prev=null");
}
#[test] fn e04_emission_is_deterministic() {
    let g = mixed_failures();
    assert_eq!(emitter().emit_pending(g.log(), NOW).attestations, emitter().emit_pending(g.log(), NOW).attestations);
}
#[test] fn e05_raw_capture_never_leaves_the_boundary() {
    let g = mixed_failures();
    assert!(g.log().records().next().unwrap().capture.windows(16).any(|w| w == b"SECRETSECRET1234"), "precondition: log retains the bytes");
    let caps: Vec<Vec<u8>> = g.log().records().map(|r| r.capture.clone()).collect();
    let allowed = ["anomaly_type", "hash", "stage", "code", "seq", "input_len", "input_digest", "record_digest", "prev_record_digest", "offset", "path"];
    for a in emitter().emit_pending(g.log(), NOW).attestations {
        assert!(!a.windows(16).any(|w| w == b"SECRETSECRET1234"));
        // Encoded leaks count too: neither the base64url nor the hex form of any capture may appear.
        for c in caps.iter().filter(|c| c.len() >= 8) {
            let (b, h) = (encode_b64url(c), c.iter().map(|x| format!("{:02x}", x)).collect::<String>());
            assert!(!a.windows(b.len()).any(|w| w == b.as_bytes()), "base64url capture leaked");
            assert!(!a.windows(h.len()).any(|w| w == h.as_bytes()), "hex capture leaked");
        }
        // Allowlist: any new body field (a leak by another name) fails here.
        for (k, _) in body(&a) { assert!(allowed.contains(&k.as_str()), "unexpected body field {}", k); }
    }
}
#[test] fn e06_cursor_emits_each_record_exactly_once() {
    let mut g = vgate(1024);
    let mut e = emitter();
    let _ = g.admit(&[1]); let _ = g.admit(&[2]);
    assert_eq!(e.emit_pending(g.log(), NOW).attestations.len(), 2);
    assert_eq!(e.emit_pending(g.log(), NOW).attestations.len(), 0);
    let _ = g.admit(&[3]);
    let more = e.emit_pending(g.log(), NOW + 1).attestations;
    assert_eq!(more.len(), 1);
    assert_eq!(e.next_seq(), 3);
    assert_eq!(field(&body(&more[0]), "seq"), Some(D::Uint(2)));
}
#[test] fn e07_eviction_before_emission_is_announced_by_a_gap_attestation() {
    let mut g = vgate(3);
    for n in 0..10u8 { let _ = g.admit(&[n]); }
    let mut e = emitter();
    let batch = e.emit_pending(g.log(), NOW);
    assert_eq!(batch.gaps, 1);
    assert_eq!(batch.attestations.len(), 4);
    let gap = body(&batch.attestations[0]);
    assert_eq!(field(&gap, "anomaly_type"), Some(D::Text("failure_gap".into())));
    assert_eq!(field(&gap, "from_seq"), Some(D::Uint(0)));
    assert_eq!(field(&gap, "to_seq"), Some(D::Uint(7)));
    assert_eq!(field(&gap, "anchor_digest"), Some(D::Text(encode_b64url(&g.log().anchor()))));
    assert_eq!(field(&body(&batch.attestations[1]), "seq"), Some(D::Uint(7)));
    assert_eq!(verify_emitted_chain(&batch.attestations), Ok(()));
    let mut reader = Gate::new_verifying(Limits::default(), LogConfig::default());
    for a in &batch.attestations { assert!(matches!(reader.admit(a), Admission::Accepted(_))); }
}
#[test] fn e08_every_single_bit_flip_of_an_emitted_attestation_is_rejected() {
    let g = mixed_failures();
    let a = emitter().emit_pending(g.log(), NOW).attestations.remove(2);
    let mut accepted = 0;
    for i in 0..a.len() { for bit in 0..8 {
        let mut m = a.clone(); m[i] ^= 1 << bit;
        let mut r = Gate::new_verifying(Limits::default(), LogConfig::default());
        if matches!(r.admit(&m), Admission::Accepted(_)) { accepted += 1; }
    } }
    assert_eq!(accepted, 0, "a mutated attestation was admitted");
}
#[test] fn e09_signer_failure_stops_the_cursor_and_retry_resumes_without_loss() {
    struct Flaky { inner: ReferenceSigner, budget: Rc<Cell<i64>> }
    impl Signer for Flaky {
        fn public_key(&self) -> [u8; 32] { self.inner.public_key() }
        fn sign(&self, m: &[u8]) -> Result<[u8; 64], SignError> {
            if self.budget.get() <= 0 { return Err(SignError); }
            self.budget.set(self.budget.get() - 1);
            self.inner.sign(m)
        }
    }
    let budget = Rc::new(Cell::new(2));
    let mut e = Emitter::new(cfg(), Flaky { inner: signer(), budget: budget.clone() }).unwrap();
    let mut g = vgate(1024);
    for n in 0..5u8 { let _ = g.admit(&[n]); }
    let first = e.emit_pending(g.log(), NOW);
    assert_eq!(first.attestations.len(), 2);
    assert_eq!(first.error, Some(SignError));
    assert_eq!(e.next_seq(), 2);
    budget.set(100);
    let second = e.emit_pending(g.log(), NOW);
    assert!(second.error.is_none());
    assert_eq!(second.attestations.len(), 3);
    let all: Vec<Vec<u8>> = first.attestations.into_iter().chain(second.attestations).collect();
    assert_eq!(verify_emitted_chain(&all), Ok(()), "chain must be unbroken across the failed attempt");
}
#[test] fn e10_attestation_carries_the_signers_key_and_configured_identity() {
    let g = mixed_failures();
    let a = emitter().emit_pending(g.log(), NOW).attestations.remove(0);
    let d = decode_envelope(&a, &Limits::default()).unwrap();
    let att = l8p_core::model::validate(&d).unwrap();
    assert_eq!(att.pk, encode_b64url(&signer().public_key()));
    assert_eq!(att.sub, "gate-01");
    assert_eq!(att.meta.scope, "h1.3-failures");
    assert_eq!(att.ts_unix_ns, NOW);
    assert!(att.wit.is_empty());
    assert_eq!(att.prev, None);
}
#[test] fn e11_rfc3339_matches_python_datetime() {
    let rows: &[(u64, &str)] = &[
    (0u64, "1970-01-01T00:00:00.000000000Z"),
    (951782400000000005u64, "2000-02-29T00:00:00.000000005Z"),
    (1789000000123456789u64, "2026-09-10T00:26:40.123456789Z"),
    (1709164800000000000u64, "2024-02-29T00:00:00.000000000Z"),
    (1709251199999999999u64, "2024-02-29T23:59:59.999999999Z"),
    (4102444800000000000u64, "2100-01-01T00:00:00.000000000Z"),
    (18446744073709551615u64, "2554-07-21T23:34:33.709551615Z"),
    (86399000000000u64, "1970-01-01T23:59:59.000000000Z"),
    (1234567890000000000u64, "2009-02-13T23:31:30.000000000Z"),
    ];
    for (ns, want) in rows { assert_eq!(&rfc3339_from_unix_ns(*ns), want, "ns {}", ns); }
}
#[test] fn e12_ids_are_deterministic_version8_uuids() {
    let g = mixed_failures();
    let (a, b) = (emitter().emit_pending(g.log(), NOW).attestations, emitter().emit_pending(g.log(), NOW + 5).attestations);
    let id = |e: &Vec<u8>| match decode_envelope(e, &Limits::default()).unwrap() {
        D::Map(m) => m.into_iter().find_map(|(k, v)| match (k, v) { (D::Text(k), D::Text(v)) if k == "id" => Some(v), _ => None }).unwrap(),
        _ => panic!(),
    };
    for (x, y) in a.iter().zip(b.iter()) { assert_eq!(id(x), id(y), "same record -> same id regardless of emit time"); }
    let ids: Vec<String> = a.iter().map(id).collect();
    for i in &ids { assert_eq!(i.as_bytes()[14], b'8'); assert!(matches!(i.as_bytes()[19], b'8' | b'9' | b'a' | b'b')); }
    let mut u = ids.clone(); u.sort(); u.dedup();
    assert_eq!(u.len(), ids.len(), "distinct records must get distinct ids");
}
#[test] fn e13_untrusted_field_names_stay_bounded_in_the_published_path() {
    let mut g = Gate::new(Limits::default(), LogConfig::default());
    let mut a = common::identity_att(); a.push(("k".repeat(4000), common::V::U(1)));
    let _ = g.admit(&common::env(&common::enc(&common::f(&a))));
    let att = emitter().emit_pending(g.log(), NOW).attestations.remove(0);
    match field(&body(&att), "path") { Some(D::Text(p)) => assert!(p.len() <= 128), o => panic!("{:?}", o) }
}
#[test] fn e14_emission_never_mutates_the_log() {
    let g = mixed_failures();
    let (head, n) = (g.log().head(), g.log().retained());
    let _ = emitter().emit_pending(g.log(), NOW);
    assert_eq!(g.log().head(), head); assert_eq!(g.log().retained(), n);
    assert!(g.log().verify().is_ok());
}
#[test] fn e15_config_validation() {
    let mut c = cfg(); c.subject = String::new();
    assert!(Emitter::new(c, signer()).is_err());
    let mut c = cfg(); c.subject = "x".repeat(257);
    assert!(Emitter::new(c, signer()).is_err());
    let mut c = cfg(); c.env = "x".repeat(4097);
    assert!(Emitter::new(c, signer()).is_err());
}
#[test] fn e16_empty_log_emits_nothing_and_random_workloads_always_reverify() {
    let g = vgate(16);
    assert!(emitter().emit_pending(g.log(), NOW).attestations.is_empty());
    let mut g = vgate(8);
    let mut p = Prng(0x51ED);
    let mut e = emitter();
    let mut all = vec![];
    for round in 0..6 {
        for _ in 0..(p.next() % 12) { let n = (p.next() % 20) as usize; let v: Vec<u8> = (0..n).map(|_| p.next() as u8).collect(); let _ = g.admit(&v); }
        let b = e.emit_pending(g.log(), NOW + round);
        assert!(b.error.is_none());
        all.extend(b.attestations);
    }
    assert_eq!(verify_emitted_chain(&all), Ok(()));
    let mut reader = Gate::new_verifying(Limits::default(), LogConfig::default());
    for a in &all { assert!(matches!(reader.admit(a), Admission::Accepted(_))); }
    let _ = sha3_256(b"");
}
