mod common;
use common::*;
use l8p_core::crypto::sha3_256;
use l8p_core::failure::*;
use l8p_core::model::ValidationCode as C;
use l8p_core::wire::{FailureCode as F, Limits};

fn gate() -> Gate { Gate::new(Limits::default(), LogConfig::default()) }
fn valid_bytes() -> Vec<u8> { env(&enc(&f(&identity_att()))) }
fn bad_struct_bytes() -> Vec<u8> { env(&enc(&f(&without(identity_att(), "sig")))) }
fn without(mut a: Fields, k: &str) -> Fields { del(&mut a, k); a }
fn rej(a: Admission) -> u64 { match a { Admission::Rejected { seq } => seq, other => panic!("expected rejection, got {:?}", other) } }

#[test] fn h1_3_01_wire_rejection_preserved_with_code_and_offset() {
    let mut g = gate();
    let mut b = 10u32.to_be_bytes().to_vec(); b.extend_from_slice(&[1, 2, 3]);
    let seq = rej(g.admit(&b));
    let r = g.log().records().next().unwrap();
    assert_eq!(seq, 0);
    assert_eq!(r.kind, FailureKind::Wire(F::Truncated));
    assert_eq!(r.kind.stage(), Stage::Wire);
    assert_eq!(r.offset, Some(b.len()));
    assert_eq!(r.input_len, b.len() as u64);
    assert_eq!(r.input_digest, sha3_256(&b));
}
#[test] fn h1_3_02_structure_rejection_preserved_with_path() {
    let mut g = gate();
    rej(g.admit(&bad_struct_bytes()));
    let r = g.log().records().next().unwrap();
    assert_eq!(r.kind, FailureKind::Structure(C::MissingField));
    assert_eq!(r.path.as_deref(), Some("sig"));
    assert_eq!(r.offset, None);
}
#[test] fn h1_3_03_accepted_input_records_nothing() {
    let mut g = gate();
    match g.admit(&valid_bytes()) { Admission::Accepted(a) => assert_eq!(a.sub, "agent-a"), o => panic!("{:?}", o) }
    assert_eq!(g.log().retained(), 0);
    assert_eq!(g.log().total_rejected(), 0);
    assert_eq!(g.accepted_count(), 1);
    assert!(g.log().verify().is_ok());
}
#[test] fn h1_3_04_sequence_is_consecutive_across_mixed_failures() {
    let mut g = gate();
    let inputs = [vec![0u8, 1], bad_struct_bytes(), valid_bytes(), vec![], bad_struct_bytes()];
    let mut seqs = vec![];
    for i in &inputs { if let Admission::Rejected { seq } = g.admit(i) { seqs.push(seq); } }
    assert_eq!(seqs, vec![0, 1, 2, 3]);
    assert!(g.log().verify().is_ok());
}
#[test] fn h1_3_05_digest_covers_full_input_not_just_capture() {
    let mut g = Gate::new(Limits::default(), LogConfig { max_capture: 8, ..LogConfig::default() });
    let mut a = vec![0u8; 5000]; let mut b = a.clone(); b[4999] = 1;
    a[..4].copy_from_slice(&10u32.to_be_bytes()); b[..4].copy_from_slice(&10u32.to_be_bytes());
    rej(g.admit(&a)); rej(g.admit(&b));
    let rs: Vec<_> = g.log().records().collect();
    assert_eq!(rs[0].capture, rs[1].capture);
    assert_ne!(rs[0].input_digest, rs[1].input_digest);
    assert_eq!(rs[0].input_len, 5000);
}
#[test] fn h1_3_06_capture_is_bounded_and_can_be_disabled() {
    let big = vec![0xffu8; 100_000];
    let mut g = Gate::new(Limits::default(), LogConfig { max_capture: 16, ..LogConfig::default() });
    rej(g.admit(&big));
    assert_eq!(g.log().records().next().unwrap().capture.len(), 16);
    let mut g0 = Gate::new(Limits::default(), LogConfig { max_capture: 0, ..LogConfig::default() });
    rej(g0.admit(&big));
    assert!(g0.log().records().next().unwrap().capture.is_empty());
    assert!(g0.log().verify().is_ok());
}
#[test] fn h1_3_07_empty_and_fresh_logs_verify() {
    assert!(gate().log().verify().is_ok());
    let mut g = gate(); rej(g.admit(&[])); assert!(g.log().verify().is_ok());
}
#[test] fn h1_3_08_every_field_tamper_detected() {
    let mut g = gate();
    for i in [vec![1u8], bad_struct_bytes(), vec![9, 9, 9, 9, 9]] { rej(g.admit(&i)); }
    let good = g.log().snapshot();
    assert!(good.verify().is_ok());
    let muts: Vec<(&str, Box<dyn Fn(&mut FailureRecord)>)> = vec![
        ("seq", Box::new(|r| r.seq += 1)),
        ("kind", Box::new(|r| r.kind = FailureKind::Wire(F::InvalidCbor))),
        ("offset", Box::new(|r| r.offset = Some(12345))),
        ("path", Box::new(|r| r.path = Some("forged".into()))),
        ("input_len", Box::new(|r| r.input_len += 1)),
        ("input_digest", Box::new(|r| r.input_digest[0] ^= 1)),
        ("capture", Box::new(|r| r.capture.push(7))),
        ("prev_digest", Box::new(|r| r.prev_digest[0] ^= 1)),
        ("digest", Box::new(|r| r.digest[0] ^= 1)),
    ];
    for idx in 0..good.records.len() {
        for (name, m) in &muts {
            let mut s = good.clone(); m(&mut s.records[idx]);
            assert!(s.verify().is_err(), "tamper of {} at record {} went undetected", name, idx);
        }
    }
}
#[test] fn h1_3_09_deletion_and_reorder_detected_tail_truncation_needs_external_head() {
    let mut g = gate();
    for n in 1..=5u8 { rej(g.admit(&vec![n; n as usize])); }
    let good = g.log().snapshot();
    let mut del_mid = good.clone(); del_mid.records.remove(2);
    assert!(del_mid.verify().is_err());
    let mut swapped = good.clone(); swapped.records.swap(1, 2);
    assert!(swapped.verify().is_err());
    let mut dup = good.clone(); let r = dup.records[1].clone(); dup.records.insert(2, r);
    assert!(dup.verify().is_err());
    // Tail truncation with an attacker-rewritten head/next_seq is self-consistent: only an external anchor exposes it.
    let mut tail = good.clone(); tail.records.pop();
    tail.head = tail.records.last().unwrap().digest; tail.next_seq -= 1;
    assert!(tail.verify().is_ok(), "documented limitation: internally consistent truncation");
    assert!(tail.verify_against_head(g.log().head()).is_err(), "external anchor must expose it");
    assert!(good.verify_against_head(g.log().head()).is_ok());
}
#[test] fn h1_3_10_bounded_retention_with_accounted_eviction() {
    let mut g = Gate::new(Limits::default(), LogConfig { max_records: 4, ..LogConfig::default() });
    for n in 0..10u8 { rej(g.admit(&[n])); }
    let l = g.log();
    assert_eq!(l.retained(), 4);
    assert_eq!(l.evicted(), 6);
    assert_eq!(l.total_rejected(), 10);
    assert_eq!(l.records().next().unwrap().seq, 6);
    assert!(l.verify().is_ok(), "retained window must verify from the eviction anchor");
    assert_eq!(l.count(FailureKind::Wire(F::Truncated)), 10, "lifetime counters survive eviction");
    let mut s = l.snapshot(); s.evicted -= 1;
    assert!(s.verify().is_err());
}
#[test] fn h1_3_11_determinism_same_inputs_same_head() {
    let inputs = [vec![1u8, 2, 3], bad_struct_bytes(), valid_bytes(), vec![0xff; 40]];
    let run = || { let mut g = gate(); for i in &inputs { let _ = g.admit(i); } (g.log().head(), g.log().snapshot().records) };
    let (h1, r1) = run(); let (h2, r2) = run();
    assert_eq!(h1, h2); assert_eq!(r1, r2);
}
#[test] fn h1_3_12_path_from_untrusted_key_is_bounded() {
    let long_key = "k".repeat(4000);
    let a = { let mut a = identity_att(); a.push((long_key.clone(), V::U(1))); a };
    let mut g = gate();
    rej(g.admit(&env(&enc(&f(&a)))));
    let r = g.log().records().next().unwrap();
    assert_eq!(r.kind, FailureKind::Structure(C::UnknownField));
    assert!(r.path.as_ref().unwrap().len() <= 128);
    // multibyte boundary: never split a char
    let mb = "é".repeat(200);
    let a2 = { let mut a = identity_att(); a.push((mb, V::U(1))); a };
    rej(g.admit(&env(&enc(&f(&a2)))));
    assert!(g.log().records().last().unwrap().path.as_ref().unwrap().len() <= 128);
}
#[test] fn h1_3_13_rejection_never_yields_value_and_counters_add_up_under_fuzz() {
    let mut g = Gate::new(Limits::default(), LogConfig { max_records: 64, ..LogConfig::default() });
    let mut p = Prng(0xDEADBEEF);
    let base = valid_bytes();
    let (mut acc, mut rejd) = (0u64, 0u64);
    for i in 0..5000 {
        let mut m = if i % 2 == 0 { base.clone() } else { (0..(p.next() % 48)).map(|_| p.next() as u8).collect() };
        if i % 2 == 0 && !m.is_empty() { let k = (p.next() as usize) % m.len(); m[k] = p.next() as u8; }
        match g.admit(&m) { Admission::Accepted(_) => acc += 1, Admission::Rejected { .. } => rejd += 1 }
    }
    assert_eq!(acc, g.accepted_count());
    assert_eq!(rejd, g.log().total_rejected());
    assert_eq!(acc + rejd, 5000);
    assert_eq!(g.log().retained() as u64 + g.log().evicted(), rejd);
    assert!(g.log().verify().is_ok());
}
#[test] fn h1_3_14_lifetime_counters_by_code() {
    let mut g = gate();
    rej(g.admit(&[])); rej(g.admit(&[])); rej(g.admit(&bad_struct_bytes()));
    assert_eq!(g.log().count(FailureKind::Wire(F::Truncated)), 2);
    assert_eq!(g.log().count(FailureKind::Structure(C::MissingField)), 1);
    assert_eq!(g.log().count(FailureKind::Wire(F::InvalidCbor)), 0);
}
#[test] fn h1_3_15_degenerate_config_is_safe() {
    let mut g = Gate::new(Limits::default(), LogConfig { max_records: 0, max_capture: 0, max_path: 0 });
    for n in 0..5u8 { rej(g.admit(&[n])); }
    assert_eq!(g.log().retained(), 1);
    assert!(g.log().verify().is_ok());
}
#[test] fn h1_3_16_every_wire_and_structure_code_preservable() {
    for (kind, _) in FailureLog::all_wire_codes().iter().map(|c| (FailureKind::Wire(*c), ())).chain(FailureLog::all_structure_codes().iter().map(|c| (FailureKind::Structure(*c), ()))) {
        let mut l = FailureLog::new(LogConfig::default());
        l.record(kind, Some(1), Some("p"), b"x");
        assert!(l.verify().is_ok());
        assert_eq!(l.count(kind), 1, "{}", kind.code_str());
    }
}
