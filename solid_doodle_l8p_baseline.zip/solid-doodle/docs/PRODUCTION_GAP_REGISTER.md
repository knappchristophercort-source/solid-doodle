# L8P Production Gap Register

Status: initial workspace baseline, 2026-10-20. This is a work register, not a claim that any gate has passed.

## P0 — Producer signature verification

**Known risk:** a producer signature field can be structurally present without being cryptographically verified.

- [x] Add a strict reference verifier using Ed25519 and a declared trusted public key.
- [x] Define deterministic JSON serialization for the signed payload.
- [x] Add positive, tampering, invalid-signature, unknown-key, malformed-envelope, and missing-field tests.
- [ ] Run the suite in the target repository/CI environment.
- [ ] Reconcile the schema and canonical-byte contract against the existing L8P artifacts.
- [ ] Integrate verification into the actual block/ledger commit boundary; reject before persistence.
- [ ] Add a regression test proving invalid producer attestations leave the ledger unchanged.

## P1 — Persistent ledger correctness

- [ ] SQLite transaction/atomicity review.
- [ ] Deterministic replay and independent validation.
- [ ] Export/import with schema and cryptographic verification before accepting imported state.
- [ ] Restart recovery and crash-consistency adversarial tests.
- [ ] Tamper detection for primary, witness, and succession records.

## P1 — Key lifecycle

- [ ] Specify key IDs, algorithm identifiers, key validity windows, and registry provenance.
- [ ] Rotation and revocation semantics.
- [ ] Succession authorization and anti-replay rules.
- [ ] Ensure builders, reference verifier, persistent harness, and app-policy adapter apply the same lifecycle rules.
- [ ] Unknown, revoked, expired, or ambiguously succeeded keys fail closed.

## P1 — Policy and constitutional boundary

- [ ] Keep cryptographic validity distinct from constitutional legitimacy.
- [ ] Enforce expected parent hash, constitution version, procedure, quorum, and domain-independence rules at the governance boundary.
- [ ] Quarantine constitution-version mismatch; reject replay and lineage failures.
- [ ] Keep oversight bounded; do not introduce recursive unbounded sentinel authority.

## P2 — Interoperability and release candidate

- [ ] Stable, versioned serialization and schema.
- [ ] Cross-implementation vectors and golden test fixtures.
- [ ] Positive and negative integration tests.
- [ ] Reproducible build/test instructions and CI.
- [ ] Documented threat model and release criteria.

## Integration warning

The verifier in this workspace is intentionally a narrow reference primitive. It does not implement a key registry, replay database, producer lifecycle policy, witness quorum, chain validation, or ledger commit transaction. A valid signature proves that the matching private key signed the defined payload bytes; it does not prove that the key is authorized, the event is fresh, the event belongs to the correct chain, or the event is constitutionally legitimate.
