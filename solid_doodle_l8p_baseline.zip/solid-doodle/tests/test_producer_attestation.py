import base64
import copy
import json

import pytest
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from l8p.producer_attestation import (
    AttestationError,
    canonical_payload,
    verify_producer_attestation,
)


@pytest.fixture
def keypair():
    private = Ed25519PrivateKey.generate()
    public_bytes = private.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    return private, public_bytes


def make_envelope(private, payload=None, key_id="producer-key-1"):
    payload = payload or {
        "attestation_id": "att-0001",
        "producer_id": "producer-01",
        "issued_at": "2026-10-20T12:00:00Z",
        "body": {"event": "block-produced", "height": 1},
    }
    signature = private.sign(canonical_payload(payload))
    return {
        "schema": "l8p.producer-attestation.v1",
        "key_id": key_id,
        "payload": payload,
        "signature": base64.b64encode(signature).decode("ascii"),
    }


def test_valid_signature_is_verified(keypair):
    private, public = keypair
    result = verify_producer_attestation(
        make_envelope(private), {"producer-key-1": public}
    )
    assert result.verified is True
    assert result.reason == "ed25519_signature_valid"
    assert result.payload["attestation_id"] == "att-0001"


def test_payload_tampering_is_rejected(keypair):
    private, public = keypair
    envelope = make_envelope(private)
    envelope["payload"]["body"]["height"] = 2
    with pytest.raises(AttestationError, match="verification failed"):
        verify_producer_attestation(envelope, {"producer-key-1": public})


def test_signature_shaped_but_invalid_value_is_rejected(keypair):
    _, public = keypair
    envelope = {
        "schema": "l8p.producer-attestation.v1",
        "key_id": "producer-key-1",
        "payload": {
            "attestation_id": "att-0001",
            "producer_id": "producer-01",
            "issued_at": "2026-10-20T12:00:00Z",
            "body": {"event": "block-produced", "height": 1},
        },
        "signature": base64.b64encode(b"x" * 64).decode("ascii"),
    }
    with pytest.raises(AttestationError, match="verification failed"):
        verify_producer_attestation(envelope, {"producer-key-1": public})


def test_unknown_key_is_rejected(keypair):
    private, _ = keypair
    envelope = make_envelope(private)
    with pytest.raises(AttestationError, match="unknown producer key"):
        verify_producer_attestation(envelope, {})


def test_wrong_signature_length_is_rejected(keypair):
    private, public = keypair
    envelope = make_envelope(private)
    envelope["signature"] = base64.b64encode(b"x" * 63).decode("ascii")
    with pytest.raises(AttestationError, match="exactly 64 bytes"):
        verify_producer_attestation(envelope, {"producer-key-1": public})


def test_extra_envelope_fields_fail_closed(keypair):
    private, public = keypair
    envelope = make_envelope(private)
    envelope["verified"] = True
    with pytest.raises(AttestationError, match="fields mismatch"):
        verify_producer_attestation(envelope, {"producer-key-1": public})


def test_missing_required_payload_field_fails_closed(keypair):
    private, public = keypair
    payload = {
        "attestation_id": "att-0001",
        "producer_id": "producer-01",
        "issued_at": "2026-10-20T12:00:00Z",
        "body": {},
    }
    envelope = make_envelope(private, payload)
    del envelope["payload"]["producer_id"]
    with pytest.raises(AttestationError, match="missing required fields"):
        verify_producer_attestation(envelope, {"producer-key-1": public})


def test_canonical_json_is_key_order_independent():
    left = {"z": 1, "a": {"y": 2, "b": 3}}
    right = {"a": {"b": 3, "y": 2}, "z": 1}
    assert canonical_payload(left) == canonical_payload(right)


def test_non_finite_number_is_rejected():
    with pytest.raises(AttestationError, match="canonicalizable"):
        canonical_payload({"not_a_number": float("nan")})
