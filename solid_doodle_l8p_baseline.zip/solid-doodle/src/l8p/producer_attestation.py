"""Strict Ed25519 producer-attestation verification.

Protocol slice status: reference implementation, not yet integrated with a ledger.
The signed bytes are the UTF-8 canonical JSON encoding of the `payload` object.
The envelope's `key_id` selects a trusted public key; it is not itself signed.
Applications must bind key IDs to an authenticated key registry and apply lifecycle
policy (revocation, rotation, succession) before accepting the result.
"""
from __future__ import annotations

import base64
import binascii
import json
from dataclasses import dataclass
from typing import Any, Mapping

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey


class AttestationError(ValueError):
    """Raised when an attestation is malformed or cannot be verified."""


@dataclass(frozen=True)
class VerificationResult:
    verified: bool
    key_id: str
    payload: dict[str, Any]
    payload_bytes: bytes
    reason: str


_REQUIRED_PAYLOAD_FIELDS = frozenset({"attestation_id", "producer_id", "issued_at", "body"})
_REQUIRED_ENVELOPE_FIELDS = frozenset({"schema", "key_id", "payload", "signature"})
_SCHEMA = "l8p.producer-attestation.v1"


def canonical_payload(payload: Mapping[str, Any]) -> bytes:
    """Serialize a JSON payload deterministically; reject non-JSON values."""
    if not isinstance(payload, Mapping):
        raise AttestationError("payload must be a JSON object")
    try:
        encoded = json.dumps(
            payload,
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
            allow_nan=False,
        ).encode("utf-8")
    except (TypeError, ValueError, UnicodeError) as exc:
        raise AttestationError("payload is not canonicalizable JSON") from exc
    return encoded


def _strict_string(value: Any, field: str) -> str:
    if not isinstance(value, str) or not value or value.strip() != value:
        raise AttestationError(f"{field} must be a non-empty trimmed string")
    return value


def verify_producer_attestation(
    envelope: Mapping[str, Any],
    trusted_public_keys: Mapping[str, bytes],
) -> VerificationResult:
    """Validate envelope shape and cryptographically verify its Ed25519 signature.

    `trusted_public_keys` maps key IDs to raw 32-byte Ed25519 public keys.
    Signature is base64 encoding of the 64-byte Ed25519 signature.
    The caller must not commit the attestation unless this function returns verified.
    """
    if not isinstance(envelope, Mapping):
        raise AttestationError("envelope must be a JSON object")
    if set(envelope.keys()) != _REQUIRED_ENVELOPE_FIELDS:
        missing = sorted(_REQUIRED_ENVELOPE_FIELDS - set(envelope.keys()))
        extra = sorted(set(envelope.keys()) - _REQUIRED_ENVELOPE_FIELDS)
        raise AttestationError(f"envelope fields mismatch; missing={missing}, extra={extra}")

    if envelope["schema"] != _SCHEMA:
        raise AttestationError("unsupported attestation schema")

    key_id = _strict_string(envelope["key_id"], "key_id")
    if key_id not in trusted_public_keys:
        raise AttestationError("unknown producer key")

    payload = envelope["payload"]
    if not isinstance(payload, dict):
        raise AttestationError("payload must be a JSON object")
    missing_payload = _REQUIRED_PAYLOAD_FIELDS - set(payload)
    if missing_payload:
        raise AttestationError(f"payload missing required fields: {sorted(missing_payload)}")

    _strict_string(payload["attestation_id"], "attestation_id")
    _strict_string(payload["producer_id"], "producer_id")
    _strict_string(payload["issued_at"], "issued_at")
    if not isinstance(payload["body"], dict):
        raise AttestationError("body must be a JSON object")

    raw_key = trusted_public_keys[key_id]
    if not isinstance(raw_key, bytes) or len(raw_key) != 32:
        raise AttestationError("trusted public key must be exactly 32 raw bytes")

    signature_text = _strict_string(envelope["signature"], "signature")
    try:
        signature = base64.b64decode(signature_text, validate=True)
    except (binascii.Error, ValueError) as exc:
        raise AttestationError("signature must be valid base64") from exc
    if len(signature) != 64:
        raise AttestationError("Ed25519 signature must decode to exactly 64 bytes")

    payload_bytes = canonical_payload(payload)
    try:
        Ed25519PublicKey.from_public_bytes(raw_key).verify(signature, payload_bytes)
    except InvalidSignature as exc:
        raise AttestationError("producer signature verification failed") from exc
    except ValueError as exc:
        raise AttestationError("invalid Ed25519 public key") from exc

    return VerificationResult(
        verified=True,
        key_id=key_id,
        payload=dict(payload),
        payload_bytes=payload_bytes,
        reason="ed25519_signature_valid",
    )
