# Level 8 Protocol (L8P) — The Observer

**Not the Judge — The Witness.**

This repository is the active engineering workspace for Level 8 Protocol (L8P), an evidence-first protocol for identity, attestation, witness records, provenance, and tamper-evident continuity.

## Engineering principles

- **Fail closed:** missing, malformed, unverifiable, or contradictory evidence is not accepted as verified.
- **No structural-only signature checks:** signature-shaped text is never proof of a valid signature.
- **Independent verification:** verifiers use a declared public key and verify the exact canonical bytes defined by the protocol.
- **Preserve uncertainty:** missing evidence, power loss, and chain gaps remain unknown/gaps; they are not silently converted into proof of compromise or proof of integrity.
- **Constitutional separation:** cryptographic validity does not itself establish constitutional legitimacy.
- **Auditable change:** implementation claims must be backed by tests and reproducible evidence.

## First implementation gate

The highest-priority known production risk is producer attestations that may be accepted based on signature shape rather than cryptographic verification. This baseline implements a narrow verification primitive and adversarial tests. It does not yet implement a persistent ledger or production orchestration.

## Layout

- `docs/PRODUCTION_GAP_REGISTER.md` — known gaps and acceptance gates.
- `src/l8p/producer_attestation.py` — strict producer-attestation verification.
- `tests/test_producer_attestation.py` — positive and negative tests.

## Development

Python 3.11 or later is recommended.

```bash
python -m pip install -e ".[test]"
pytest
```

The current slice is **not a declaration of production readiness**. Persistent ledger replay, import/export validation, key rotation/revocation/succession, policy orchestration, and full cross-component integration remain separate acceptance gates.
